/*******************************************************************************
* File Name: CS_DAB_2_IsCurrent_PM.c
* Version 3.10
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "CS_DAB_2_IsCurrent.h"

static CS_DAB_2_IsCurrent_backupStruct CS_DAB_2_IsCurrent_backup;


/*******************************************************************************
* Function Name: CS_DAB_2_IsCurrent_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  CS_DAB_2_IsCurrent_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void CS_DAB_2_IsCurrent_SaveConfig(void) 
{

    #if(!CS_DAB_2_IsCurrent_UsingFixedFunction)
        #if(!CS_DAB_2_IsCurrent_PWMModeIsCenterAligned)
            CS_DAB_2_IsCurrent_backup.PWMPeriod = CS_DAB_2_IsCurrent_ReadPeriod();
        #endif /* (!CS_DAB_2_IsCurrent_PWMModeIsCenterAligned) */
        CS_DAB_2_IsCurrent_backup.PWMUdb = CS_DAB_2_IsCurrent_ReadCounter();
        #if (CS_DAB_2_IsCurrent_UseStatus)
            CS_DAB_2_IsCurrent_backup.InterruptMaskValue = CS_DAB_2_IsCurrent_STATUS_MASK;
        #endif /* (CS_DAB_2_IsCurrent_UseStatus) */

        #if(CS_DAB_2_IsCurrent_DeadBandMode == CS_DAB_2_IsCurrent__B_PWM__DBM_256_CLOCKS || \
            CS_DAB_2_IsCurrent_DeadBandMode == CS_DAB_2_IsCurrent__B_PWM__DBM_2_4_CLOCKS)
            CS_DAB_2_IsCurrent_backup.PWMdeadBandValue = CS_DAB_2_IsCurrent_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(CS_DAB_2_IsCurrent_KillModeMinTime)
             CS_DAB_2_IsCurrent_backup.PWMKillCounterPeriod = CS_DAB_2_IsCurrent_ReadKillTime();
        #endif /* (CS_DAB_2_IsCurrent_KillModeMinTime) */

        #if(CS_DAB_2_IsCurrent_UseControl)
            CS_DAB_2_IsCurrent_backup.PWMControlRegister = CS_DAB_2_IsCurrent_ReadControlRegister();
        #endif /* (CS_DAB_2_IsCurrent_UseControl) */
    #endif  /* (!CS_DAB_2_IsCurrent_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: CS_DAB_2_IsCurrent_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  CS_DAB_2_IsCurrent_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void CS_DAB_2_IsCurrent_RestoreConfig(void) 
{
        #if(!CS_DAB_2_IsCurrent_UsingFixedFunction)
            #if(!CS_DAB_2_IsCurrent_PWMModeIsCenterAligned)
                CS_DAB_2_IsCurrent_WritePeriod(CS_DAB_2_IsCurrent_backup.PWMPeriod);
            #endif /* (!CS_DAB_2_IsCurrent_PWMModeIsCenterAligned) */

            CS_DAB_2_IsCurrent_WriteCounter(CS_DAB_2_IsCurrent_backup.PWMUdb);

            #if (CS_DAB_2_IsCurrent_UseStatus)
                CS_DAB_2_IsCurrent_STATUS_MASK = CS_DAB_2_IsCurrent_backup.InterruptMaskValue;
            #endif /* (CS_DAB_2_IsCurrent_UseStatus) */

            #if(CS_DAB_2_IsCurrent_DeadBandMode == CS_DAB_2_IsCurrent__B_PWM__DBM_256_CLOCKS || \
                CS_DAB_2_IsCurrent_DeadBandMode == CS_DAB_2_IsCurrent__B_PWM__DBM_2_4_CLOCKS)
                CS_DAB_2_IsCurrent_WriteDeadTime(CS_DAB_2_IsCurrent_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(CS_DAB_2_IsCurrent_KillModeMinTime)
                CS_DAB_2_IsCurrent_WriteKillTime(CS_DAB_2_IsCurrent_backup.PWMKillCounterPeriod);
            #endif /* (CS_DAB_2_IsCurrent_KillModeMinTime) */

            #if(CS_DAB_2_IsCurrent_UseControl)
                CS_DAB_2_IsCurrent_WriteControlRegister(CS_DAB_2_IsCurrent_backup.PWMControlRegister);
            #endif /* (CS_DAB_2_IsCurrent_UseControl) */
        #endif  /* (!CS_DAB_2_IsCurrent_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: CS_DAB_2_IsCurrent_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  CS_DAB_2_IsCurrent_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void CS_DAB_2_IsCurrent_Sleep(void) 
{
    #if(CS_DAB_2_IsCurrent_UseControl)
        if(CS_DAB_2_IsCurrent_CTRL_ENABLE == (CS_DAB_2_IsCurrent_CONTROL & CS_DAB_2_IsCurrent_CTRL_ENABLE))
        {
            /*Component is enabled */
            CS_DAB_2_IsCurrent_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            CS_DAB_2_IsCurrent_backup.PWMEnableState = 0u;
        }
    #endif /* (CS_DAB_2_IsCurrent_UseControl) */

    /* Stop component */
    CS_DAB_2_IsCurrent_Stop();

    /* Save registers configuration */
    CS_DAB_2_IsCurrent_SaveConfig();
}


/*******************************************************************************
* Function Name: CS_DAB_2_IsCurrent_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  CS_DAB_2_IsCurrent_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void CS_DAB_2_IsCurrent_Wakeup(void) 
{
     /* Restore registers values */
    CS_DAB_2_IsCurrent_RestoreConfig();

    if(CS_DAB_2_IsCurrent_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        CS_DAB_2_IsCurrent_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
