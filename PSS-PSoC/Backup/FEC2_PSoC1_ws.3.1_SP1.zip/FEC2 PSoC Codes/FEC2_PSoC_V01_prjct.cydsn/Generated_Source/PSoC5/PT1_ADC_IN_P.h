/*******************************************************************************
* File Name: PT1_ADC_IN_P.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PT1_ADC_IN_P_H) /* Pins PT1_ADC_IN_P_H */
#define CY_PINS_PT1_ADC_IN_P_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PT1_ADC_IN_P_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PT1_ADC_IN_P__PORT == 15 && ((PT1_ADC_IN_P__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    PT1_ADC_IN_P_Write(uint8 value) ;
void    PT1_ADC_IN_P_SetDriveMode(uint8 mode) ;
uint8   PT1_ADC_IN_P_ReadDataReg(void) ;
uint8   PT1_ADC_IN_P_Read(void) ;
uint8   PT1_ADC_IN_P_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PT1_ADC_IN_P_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define PT1_ADC_IN_P_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define PT1_ADC_IN_P_DM_RES_UP          PIN_DM_RES_UP
#define PT1_ADC_IN_P_DM_RES_DWN         PIN_DM_RES_DWN
#define PT1_ADC_IN_P_DM_OD_LO           PIN_DM_OD_LO
#define PT1_ADC_IN_P_DM_OD_HI           PIN_DM_OD_HI
#define PT1_ADC_IN_P_DM_STRONG          PIN_DM_STRONG
#define PT1_ADC_IN_P_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define PT1_ADC_IN_P_MASK               PT1_ADC_IN_P__MASK
#define PT1_ADC_IN_P_SHIFT              PT1_ADC_IN_P__SHIFT
#define PT1_ADC_IN_P_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PT1_ADC_IN_P_PS                     (* (reg8 *) PT1_ADC_IN_P__PS)
/* Data Register */
#define PT1_ADC_IN_P_DR                     (* (reg8 *) PT1_ADC_IN_P__DR)
/* Port Number */
#define PT1_ADC_IN_P_PRT_NUM                (* (reg8 *) PT1_ADC_IN_P__PRT) 
/* Connect to Analog Globals */                                                  
#define PT1_ADC_IN_P_AG                     (* (reg8 *) PT1_ADC_IN_P__AG)                       
/* Analog MUX bux enable */
#define PT1_ADC_IN_P_AMUX                   (* (reg8 *) PT1_ADC_IN_P__AMUX) 
/* Bidirectional Enable */                                                        
#define PT1_ADC_IN_P_BIE                    (* (reg8 *) PT1_ADC_IN_P__BIE)
/* Bit-mask for Aliased Register Access */
#define PT1_ADC_IN_P_BIT_MASK               (* (reg8 *) PT1_ADC_IN_P__BIT_MASK)
/* Bypass Enable */
#define PT1_ADC_IN_P_BYP                    (* (reg8 *) PT1_ADC_IN_P__BYP)
/* Port wide control signals */                                                   
#define PT1_ADC_IN_P_CTL                    (* (reg8 *) PT1_ADC_IN_P__CTL)
/* Drive Modes */
#define PT1_ADC_IN_P_DM0                    (* (reg8 *) PT1_ADC_IN_P__DM0) 
#define PT1_ADC_IN_P_DM1                    (* (reg8 *) PT1_ADC_IN_P__DM1)
#define PT1_ADC_IN_P_DM2                    (* (reg8 *) PT1_ADC_IN_P__DM2) 
/* Input Buffer Disable Override */
#define PT1_ADC_IN_P_INP_DIS                (* (reg8 *) PT1_ADC_IN_P__INP_DIS)
/* LCD Common or Segment Drive */
#define PT1_ADC_IN_P_LCD_COM_SEG            (* (reg8 *) PT1_ADC_IN_P__LCD_COM_SEG)
/* Enable Segment LCD */
#define PT1_ADC_IN_P_LCD_EN                 (* (reg8 *) PT1_ADC_IN_P__LCD_EN)
/* Slew Rate Control */
#define PT1_ADC_IN_P_SLW                    (* (reg8 *) PT1_ADC_IN_P__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PT1_ADC_IN_P_PRTDSI__CAPS_SEL       (* (reg8 *) PT1_ADC_IN_P__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PT1_ADC_IN_P_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PT1_ADC_IN_P__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PT1_ADC_IN_P_PRTDSI__OE_SEL0        (* (reg8 *) PT1_ADC_IN_P__PRTDSI__OE_SEL0) 
#define PT1_ADC_IN_P_PRTDSI__OE_SEL1        (* (reg8 *) PT1_ADC_IN_P__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PT1_ADC_IN_P_PRTDSI__OUT_SEL0       (* (reg8 *) PT1_ADC_IN_P__PRTDSI__OUT_SEL0) 
#define PT1_ADC_IN_P_PRTDSI__OUT_SEL1       (* (reg8 *) PT1_ADC_IN_P__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PT1_ADC_IN_P_PRTDSI__SYNC_OUT       (* (reg8 *) PT1_ADC_IN_P__PRTDSI__SYNC_OUT) 


#if defined(PT1_ADC_IN_P__INTSTAT)  /* Interrupt Registers */

    #define PT1_ADC_IN_P_INTSTAT                (* (reg8 *) PT1_ADC_IN_P__INTSTAT)
    #define PT1_ADC_IN_P_SNAP                   (* (reg8 *) PT1_ADC_IN_P__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PT1_ADC_IN_P_H */


/* [] END OF FILE */
