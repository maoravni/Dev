/*******************************************************************************
* File Name: DSM_IRQ.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_DSM_IRQ_H)
#define CY_ISR_DSM_IRQ_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void DSM_IRQ_Start(void);
void DSM_IRQ_StartEx(cyisraddress address);
void DSM_IRQ_Stop(void);

CY_ISR_PROTO(DSM_IRQ_Interrupt);

void DSM_IRQ_SetVector(cyisraddress address);
cyisraddress DSM_IRQ_GetVector(void);

void DSM_IRQ_SetPriority(uint8 priority);
uint8 DSM_IRQ_GetPriority(void);

void DSM_IRQ_Enable(void);
uint8 DSM_IRQ_GetState(void);
void DSM_IRQ_Disable(void);

void DSM_IRQ_SetPending(void);
void DSM_IRQ_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the DSM_IRQ ISR. */
#define DSM_IRQ_INTC_VECTOR            ((reg32 *) DSM_IRQ__INTC_VECT)

/* Address of the DSM_IRQ ISR priority. */
#define DSM_IRQ_INTC_PRIOR             ((reg8 *) DSM_IRQ__INTC_PRIOR_REG)

/* Priority of the DSM_IRQ interrupt. */
#define DSM_IRQ_INTC_PRIOR_NUMBER      DSM_IRQ__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable DSM_IRQ interrupt. */
#define DSM_IRQ_INTC_SET_EN            ((reg32 *) DSM_IRQ__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the DSM_IRQ interrupt. */
#define DSM_IRQ_INTC_CLR_EN            ((reg32 *) DSM_IRQ__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the DSM_IRQ interrupt state to pending. */
#define DSM_IRQ_INTC_SET_PD            ((reg32 *) DSM_IRQ__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the DSM_IRQ interrupt. */
#define DSM_IRQ_INTC_CLR_PD            ((reg32 *) DSM_IRQ__INTC_CLR_PD_REG)


#endif /* CY_ISR_DSM_IRQ_H */


/* [] END OF FILE */
