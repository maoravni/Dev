/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <cytypes.h>

#if !defined (DOD_H )
#define DOD_H 
	
#define DOD_MAX_PULSE_DENSITY 	(float) (0xFFFF / 100)

typedef struct
{
	uint8 SlowPWM1:2;
	uint8 SlowPWM2:1;
	uint8 PWM1:1;
	uint8 PWM2:1;
	uint8 HB_PWM1:1;
	uint8 HB_PWM2:1;
}T_DOD_Configuration;
	
void DOD_Start(void);

uint8 DOD_OutConfig(uint8 Channel, uint8 Config);

uint8 DOD_SlowPWM1_Write(uint8 dc);
uint8 DOD_SlowPWM2_Write(uint8 dc);
uint8 DOD_PWMOut1_Write(uint8 dc);
uint8 DOD_PWMOut2_Write(uint8 dc);
uint8 DOD_HB_PWMOut1_Write(uint8 dc);
uint8 DOD_HB_PWMOut2_Write(uint8 dc);

#endif
/* [] END OF FILE */
