/*******************************************************************************
* File Name: safety_feedback.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_safety_feedback_H) /* Pins safety_feedback_H */
#define CY_PINS_safety_feedback_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "safety_feedback_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 safety_feedback__PORT == 15 && ((safety_feedback__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    safety_feedback_Write(uint8 value) ;
void    safety_feedback_SetDriveMode(uint8 mode) ;
uint8   safety_feedback_ReadDataReg(void) ;
uint8   safety_feedback_Read(void) ;
uint8   safety_feedback_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define safety_feedback_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define safety_feedback_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define safety_feedback_DM_RES_UP          PIN_DM_RES_UP
#define safety_feedback_DM_RES_DWN         PIN_DM_RES_DWN
#define safety_feedback_DM_OD_LO           PIN_DM_OD_LO
#define safety_feedback_DM_OD_HI           PIN_DM_OD_HI
#define safety_feedback_DM_STRONG          PIN_DM_STRONG
#define safety_feedback_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define safety_feedback_MASK               safety_feedback__MASK
#define safety_feedback_SHIFT              safety_feedback__SHIFT
#define safety_feedback_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define safety_feedback_PS                     (* (reg8 *) safety_feedback__PS)
/* Data Register */
#define safety_feedback_DR                     (* (reg8 *) safety_feedback__DR)
/* Port Number */
#define safety_feedback_PRT_NUM                (* (reg8 *) safety_feedback__PRT) 
/* Connect to Analog Globals */                                                  
#define safety_feedback_AG                     (* (reg8 *) safety_feedback__AG)                       
/* Analog MUX bux enable */
#define safety_feedback_AMUX                   (* (reg8 *) safety_feedback__AMUX) 
/* Bidirectional Enable */                                                        
#define safety_feedback_BIE                    (* (reg8 *) safety_feedback__BIE)
/* Bit-mask for Aliased Register Access */
#define safety_feedback_BIT_MASK               (* (reg8 *) safety_feedback__BIT_MASK)
/* Bypass Enable */
#define safety_feedback_BYP                    (* (reg8 *) safety_feedback__BYP)
/* Port wide control signals */                                                   
#define safety_feedback_CTL                    (* (reg8 *) safety_feedback__CTL)
/* Drive Modes */
#define safety_feedback_DM0                    (* (reg8 *) safety_feedback__DM0) 
#define safety_feedback_DM1                    (* (reg8 *) safety_feedback__DM1)
#define safety_feedback_DM2                    (* (reg8 *) safety_feedback__DM2) 
/* Input Buffer Disable Override */
#define safety_feedback_INP_DIS                (* (reg8 *) safety_feedback__INP_DIS)
/* LCD Common or Segment Drive */
#define safety_feedback_LCD_COM_SEG            (* (reg8 *) safety_feedback__LCD_COM_SEG)
/* Enable Segment LCD */
#define safety_feedback_LCD_EN                 (* (reg8 *) safety_feedback__LCD_EN)
/* Slew Rate Control */
#define safety_feedback_SLW                    (* (reg8 *) safety_feedback__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define safety_feedback_PRTDSI__CAPS_SEL       (* (reg8 *) safety_feedback__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define safety_feedback_PRTDSI__DBL_SYNC_IN    (* (reg8 *) safety_feedback__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define safety_feedback_PRTDSI__OE_SEL0        (* (reg8 *) safety_feedback__PRTDSI__OE_SEL0) 
#define safety_feedback_PRTDSI__OE_SEL1        (* (reg8 *) safety_feedback__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define safety_feedback_PRTDSI__OUT_SEL0       (* (reg8 *) safety_feedback__PRTDSI__OUT_SEL0) 
#define safety_feedback_PRTDSI__OUT_SEL1       (* (reg8 *) safety_feedback__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define safety_feedback_PRTDSI__SYNC_OUT       (* (reg8 *) safety_feedback__PRTDSI__SYNC_OUT) 


#if defined(safety_feedback__INTSTAT)  /* Interrupt Registers */

    #define safety_feedback_INTSTAT                (* (reg8 *) safety_feedback__INTSTAT)
    #define safety_feedback_SNAP                   (* (reg8 *) safety_feedback__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_safety_feedback_H */


/* [] END OF FILE */
