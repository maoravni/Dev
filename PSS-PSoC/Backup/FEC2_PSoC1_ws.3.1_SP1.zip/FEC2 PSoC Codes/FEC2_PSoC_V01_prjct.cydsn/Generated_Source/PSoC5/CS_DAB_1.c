/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include<device.h>

/*******************/
/* Global variable */
/*******************/
uint8 CS_DAB_1_initVar = 1;
uint8 CS_DAB_1_CS_ON_Counter;

uint8 CS_DAB_1_Main_DMA_Chan;
uint8 CS_DAB_1_Peak_DMA_Chan;
uint8 CS_DAB_1_Zero_DMA_Chan;
uint8 CS_DAB_1_Store_Peak_DMA_Chan;
uint8 CS_DAB_1_Store_Zero_DMA_Chan;

int16 CS_DAB_1_Peak_Data_Buffer[CS_DAB_1_SIZE_OF_PEAKS_DATA_BUFFER];
int16 CS_DAB_1_Zero_Data_Buffer[CS_DAB_1_SIZE_OF_ZERO_DATA_BUFFER];

int16 CS_DAB_1_Peak_Data[CS_DAB_1_SIZE_OF_PEAKS_DATA_BUFFER];
int16 CS_DAB_1_Zero_Data[CS_DAB_1_SIZE_OF_ZERO_DATA_BUFFER];

uint8 CS_DAB_1_P_Data_Ready      = 0;
uint8 CS_DAB_1_Z_Data_Ready      = 0;

CY_ISR(CS_DAB_1_P_ISR_Done)
{
	CS_DAB_1_P_Data_Ready = 1;
	CS_DAB_1_CS_ON_Counter++;
}

CY_ISR(CS_DAB_1_Z_ISR_Done)
{
	CS_DAB_1_Z_Data_Ready = 1;
}

void CS_DAB_1_Start()
{
	if(CS_DAB_1_initVar)
	{
		CS_DAB_1_P_Data_Ready = 0;
		CS_DAB_1_Z_Data_Ready = 0;
		CS_DAB_1_IsCurrent_WriteCounter(CS_DAB_1_ZERO_LEVEL);
		CS_DAB_1_IsCurrent_WriteCompare1(CS_DAB_1_POS_DETECT_THRESHOLD);
		CS_DAB_1_IsCurrent_WriteCompare2(CS_DAB_1_NEG_DETECT_THRESHOLD);
		/* Start the "IsCurrent" PWM module */
	    CS_DAB_1_IsCurrent_Start();
	    /* Start the NextMap Interrupt module */
		CS_DAB_1_P_isr_Start();
		CS_DAB_1_Z_isr_Start();
		/* Set the priority of that ISR */
		CS_DAB_1_P_isr_SetPriority(1);
		CS_DAB_1_Z_isr_SetPriority(2);
	    /* Give a name to the interrupt vector */
		CS_DAB_1_P_isr_SetVector(CS_DAB_1_P_ISR_Done);
	    CS_DAB_1_Z_isr_SetVector(CS_DAB_1_Z_ISR_Done);
		/* initialize the DMA's */
		CS_DAB_1_DMAs_Config();
		CS_DAB_1_initVar = 0;
	}
}

void CS_DAB_1_Stop()
{   
	if(!CS_DAB_1_initVar)
	{
	    CS_DAB_1_IsCurrent_Stop();
		/* Will Disable al the DMA's Network for the CS_DAB */
		CyDmaChDisable(CS_DAB_1_Main_DMA_Chan);
	}
}

void CS_DAB_1_Calibrate(uint16 CS_DAB_1_Zero_Level, uint16 CS_DAB_1_Detect_Thrshld)
{
	CS_DAB_1_IsCurrent_Stop();
	CS_DAB_1_IsCurrent_WriteCounter(CS_DAB_1_Zero_Level);
	CS_DAB_1_IsCurrent_WriteCompare1(CS_DAB_1_Zero_Level + CS_DAB_1_Detect_Thrshld);
	CS_DAB_1_IsCurrent_WriteCompare2(CS_DAB_1_Zero_Level - CS_DAB_1_Detect_Thrshld);
	CS_DAB_1_IsCurrent_Start();
}

void CS_DAB_1_DMAs_Config()
{
/* Main_DMA_Configuration 
***********************************************************************************************************************************************/
	uint8 CS_DAB_1_Main_DMA_TD[1];	
	/* DMA Initialization - 2 byte per trigger.Each burst transfer needs a new request. 
	Set upper source and destination address. */	
	CS_DAB_1_Main_DMA_Chan = 
		CS_DAB_1_Main_DMA_DmaInitialize(CS_DAB_1_Main_DMA_BYTES_PER_BURST, CS_DAB_1_Main_DMA_REQUEST_PER_BURST, 
	    HI16(CS_DAB_1_Main_DMA_SRC_BASE), HI16(CS_DAB_1_Main_DMA_DST_BASE));
	/* Allocate TD */	
	CS_DAB_1_Main_DMA_TD[0] = CyDmaTdAllocate();
    /* Term out generated after the specified no. of bytes are transferred to memory.
	   Tranfer the specified number of samples and generate term out */	
	CyDmaTdSetConfiguration(CS_DAB_1_Main_DMA_TD[0], 2, CS_DAB_1_Main_DMA_TD[0],CS_DAB_1_Main_DMA__TD_TERMOUT_EN);
	/* Set source and destination address */
	CyDmaTdSetAddress(	CS_DAB_1_Main_DMA_TD[0], 
						LO16((uint32)SAR2_SAR_WRK0_PTR), 
						LO16((uint32)CS_DAB_1_IsCurrent_COUNTER_LSB_PTR));
	/* Set the channel priority */
	CyDmaChPriority(CS_DAB_1_Main_DMA_Chan, 1);
	/* Set the intial TD for the channel */
	CyDmaChSetInitialTd(CS_DAB_1_Main_DMA_Chan, CS_DAB_1_Main_DMA_TD[0]);
	/* Set Channel Priorty */
	CyDmaChPriority(CS_DAB_1_Main_DMA_Chan, 1);
	/* Enable the DMA channel */
	CyDmaChEnable(CS_DAB_1_Main_DMA_Chan, 1);
/***********************************************************************************************************************************************/
	
/* Peak_DMA_Configuration 
***********************************************************************************************************************************************/
	uint8 CS_DAB_1_Peak_DMA_TD[1];	
	/* DMA Initialization - 2 byte per trigger.Each burst transfer needs a new request. 
	Set upper source and destination address. */	
	CS_DAB_1_Peak_DMA_Chan = 
		CS_DAB_1_Peak_DMA_DmaInitialize(CS_DAB_1_Peak_DMA_BYTES_PER_BURST, CS_DAB_1_Peak_DMA_REQUEST_PER_BURST, 
	    HI16(CS_DAB_1_Peak_DMA_SRC_BASE), HI16(CS_DAB_1_Peak_DMA_DST_BASE));
	/* Allocate TD */	
	CS_DAB_1_Peak_DMA_TD[0] = CyDmaTdAllocate();
    /* Term out generated after the specified no. of bytes are transferred to memory.
	   Tranfer the specified number of samples and generate term out */	
	CyDmaTdSetConfiguration(CS_DAB_1_Peak_DMA_TD[0], sizeof(CS_DAB_1_Peak_Data_Buffer), 
							CS_DAB_1_Peak_DMA_TD[0],CS_DAB_1_Peak_DMA__TD_TERMOUT_EN | TD_INC_DST_ADR);
	/* Set source and destination address */
	CyDmaTdSetAddress(CS_DAB_1_Peak_DMA_TD[0], LO16((uint32)CS_DAB_1_IsCurrent_COUNTER_LSB_PTR),
					  LO16((uint32)CS_DAB_1_Peak_Data_Buffer));
	/* Set the channel priority */
	CyDmaChPriority(CS_DAB_1_Peak_DMA_Chan, 1);
	/* Set the intial TD for the channel */
	CyDmaChSetInitialTd(CS_DAB_1_Peak_DMA_Chan, CS_DAB_1_Peak_DMA_TD[0]);
	/* Set Channel Priorty */
	CyDmaChPriority(CS_DAB_1_Peak_DMA_Chan, 1);
	/* Enable the DMA channel */
	CyDmaChEnable(CS_DAB_1_Peak_DMA_Chan, 1);
/***********************************************************************************************************************************************/
	
/* Zero_DMA_Configuration 
***********************************************************************************************************************************************/
	uint8 CS_DAB_1_Zero_DMA_TD[1];	
	/* DMA Initialization - 2 byte per trigger.Each burst transfer needs a new request. 
	Set upper source and destination address. */	
	CS_DAB_1_Zero_DMA_Chan = 
		CS_DAB_1_Zero_DMA_DmaInitialize(CS_DAB_1_Zero_DMA_BYTES_PER_BURST, CS_DAB_1_Zero_DMA_REQUEST_PER_BURST, 
	    HI16(CS_DAB_1_Zero_DMA_SRC_BASE), HI16(CS_DAB_1_Zero_DMA_DST_BASE));
	/* Allocate TD */	
	CS_DAB_1_Zero_DMA_TD[0] = CyDmaTdAllocate();
    /* Term out generated after the specified no. of bytes are transferred to memory.
	   Tranfer the specified number of samples and generate term out */	
	CyDmaTdSetConfiguration(CS_DAB_1_Zero_DMA_TD[0], sizeof(CS_DAB_1_Zero_Data_Buffer),
							CS_DAB_1_Zero_DMA_TD[0],
							CS_DAB_1_Zero_DMA__TD_TERMOUT_EN | TD_INC_DST_ADR);
	/* Set source and destination address */
	CyDmaTdSetAddress(CS_DAB_1_Zero_DMA_TD[0], LO16((uint32)CS_DAB_1_IsCurrent_COUNTER_LSB_PTR),
					  LO16((uint32)CS_DAB_1_Zero_Data_Buffer));
	/* Set the channel priority */
	CyDmaChPriority(CS_DAB_1_Zero_DMA_Chan, 1);
	/* Set the intial TD for the channel */
	CyDmaChSetInitialTd(CS_DAB_1_Zero_DMA_Chan, CS_DAB_1_Zero_DMA_TD[0]);
	/* Set Channel Priorty */
	CyDmaChPriority(CS_DAB_1_Zero_DMA_Chan, 2);
	/* Enable the DMA channel */
	CyDmaChEnable(CS_DAB_1_Zero_DMA_Chan, 1);
/***********************************************************************************************************************************************/
	
/* Store_Peak_DMA_Configuration 
***********************************************************************************************************************************************/
	uint8 CS_DAB_1_Store_Peak_DMA_TD[1];	
	/* DMA Initialization - 2 byte per trigger.Each burst transfer needs a new request. 
	Set upper source and destination address. */	
	CS_DAB_1_Store_Peak_DMA_Chan = 
		CS_DAB_1_Store_Peak_DMA_DmaInitialize(CS_DAB_1_Peak_DMA_BYTES_PER_BURST, 
		CS_DAB_1_Store_Peak_DMA_REQUEST_PER_BURST, HI16(CS_DAB_1_Store_Peak_DMA_SRC_BASE), 
		 HI16(CS_DAB_1_Peak_DMA_DST_BASE));
	/* Allocate TD */	
	CS_DAB_1_Store_Peak_DMA_TD[0] = CyDmaTdAllocate();
    /* Term out generated after the specified no. of bytes are transferred to memory.
	   Transfer the specified number of samples and generate term out */	
	CyDmaTdSetConfiguration(CS_DAB_1_Store_Peak_DMA_TD[0], sizeof(CS_DAB_1_Peak_Data_Buffer), 
							CS_DAB_1_Store_Peak_DMA_TD[0],
							CS_DAB_1_Store_Peak_DMA__TD_TERMOUT_EN | TD_INC_SRC_ADR | TD_INC_DST_ADR);
	/* Set source and destination address */
	CyDmaTdSetAddress(CS_DAB_1_Store_Peak_DMA_TD[0], LO16((uint32)CS_DAB_1_Peak_Data_Buffer),
					  LO16((uint32)CS_DAB_1_Peak_Data));
	/* Set the channel priority */
	CyDmaChPriority(CS_DAB_1_Store_Peak_DMA_Chan, 1);
	/* Set the initial TD for the channel */
	CyDmaChSetInitialTd(CS_DAB_1_Store_Peak_DMA_Chan, CS_DAB_1_Store_Peak_DMA_TD[0]);
	/* Set Channel Priorty */
	CyDmaChPriority(CS_DAB_1_Store_Peak_DMA_Chan, 2);
	/* Enable the DMA channel */
	CyDmaChEnable(CS_DAB_1_Store_Peak_DMA_Chan, 1);
/***********************************************************************************************************************************************/
/* Store_Zero_DMA_Configuration 
***********************************************************************************************************************************************/
	uint8 CS_DAB_1_Store_Zero_DMA_TD[1];	
	/* DMA Initialization - 2 byte per trigger.Each burst transfer needs a new request. 
	Set upper source and destination address. */	
	CS_DAB_1_Store_Zero_DMA_Chan = 
		CS_DAB_1_Store_Zero_DMA_DmaInitialize(CS_DAB_1_Zero_DMA_BYTES_PER_BURST, 
		CS_DAB_1_Store_Zero_DMA_REQUEST_PER_BURST, HI16(CS_DAB_1_Store_Zero_DMA_SRC_BASE), 
		 HI16(CS_DAB_1_Zero_DMA_DST_BASE));
	/* Allocate TD */	
	CS_DAB_1_Store_Zero_DMA_TD[0] = CyDmaTdAllocate();
    /* Term out generated after the specified no. of bytes are transferred to memory.
	   Transfer the specified number of samples and generate term out */	
	CyDmaTdSetConfiguration(CS_DAB_1_Store_Zero_DMA_TD[0], sizeof(CS_DAB_1_Zero_Data_Buffer), 
							CS_DAB_1_Store_Zero_DMA_TD[0],
							CS_DAB_1_Store_Zero_DMA__TD_TERMOUT_EN | TD_INC_SRC_ADR | TD_INC_DST_ADR);
	/* Set source and destination address */
	CyDmaTdSetAddress(CS_DAB_1_Store_Zero_DMA_TD[0], LO16((uint32)CS_DAB_1_Zero_Data_Buffer),
					  LO16((uint32)CS_DAB_1_Zero_Data));
	/* Set the channel priority */
	CyDmaChPriority(CS_DAB_1_Store_Zero_DMA_Chan, 1);
	/* Set the initial TD for the channel */
	CyDmaChSetInitialTd(CS_DAB_1_Store_Zero_DMA_Chan, CS_DAB_1_Store_Zero_DMA_TD[0]);
	/* Set Channel Priorty */
	CyDmaChPriority(CS_DAB_1_Store_Zero_DMA_Chan, 2);
	/* Enable the DMA channel */
	CyDmaChEnable(CS_DAB_1_Store_Zero_DMA_Chan, 1);
/***********************************************************************************************************************************************/	
}

void CS_DAB_1_Peak_DMA_Enable()
{
	/* Enable the DMA channel */
	CyDmaChEnable(CS_DAB_1_Store_Peak_DMA_Chan, 1);	
}


/* [] END OF FILE */
