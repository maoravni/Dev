/*******************************************************************************
* File Name: DSM_PM.c
* Version 3.10
*
* Description:
*  This file provides the power manager source code to the API for the
*  Delta-Sigma ADC Component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2013, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DSM.h"

static DSM_BACKUP_STRUCT DSM_backup =
{
    DSM_DISABLED,
    DSM_CFG1_DEC_CR
};


/*******************************************************************************
* Function Name: DSM_SaveConfig
********************************************************************************
*
* Summary:
*  Save the register configuration which are not retention.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_backup:  This global structure variable is used to store
*  configuration registers which are non retention whenever user wants to go
*  sleep mode by calling Sleep() API.
*
*******************************************************************************/
void DSM_SaveConfig(void) 
{
    DSM_backup.deccr = DSM_DEC_CR_REG;
}


/*******************************************************************************
* Function Name: DSM_RestoreConfig
********************************************************************************
*
* Summary:
*  Restore the register configurations which are not retention.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_backup:  This global structure variable is used to restore
*  configuration registers which are non retention whenever user wants to switch
*  to active power mode by calling Wakeup() API.
*
*******************************************************************************/
void DSM_RestoreConfig(void) 
{
    DSM_DEC_CR_REG = DSM_backup.deccr;
}


/*******************************************************************************
* Function Name: DSM_Sleep
********************************************************************************
*
* Summary:
*  Stops the operation of the block and saves the user configuration.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_backup:  The structure field 'enableState' is modified
*  depending on the enable state of the block before entering to sleep mode.
*
*******************************************************************************/
void DSM_Sleep(void) 
{
    /* Save ADC enable state */
    if((DSM_ACT_PWR_DEC_EN == (DSM_PWRMGR_DEC_REG & DSM_ACT_PWR_DEC_EN)) &&
       (DSM_ACT_PWR_DSM_EN == (DSM_PWRMGR_DSM_REG & DSM_ACT_PWR_DSM_EN)))
    {
        /* Component is enabled */
        DSM_backup.enableState = DSM_ENABLED;
        if((DSM_DEC_CR_REG & DSM_DEC_START_CONV) != 0u)
        {   
            /* Conversion is started */
            DSM_backup.enableState |= DSM_STARTED;
        }
		
        /* Stop the configuration */
        DSM_Stop();
    }
    else
    {
        /* Component is disabled */
        DSM_backup.enableState = DSM_DISABLED;
    }

    /* Save the user configuration */
    DSM_SaveConfig();
}


/*******************************************************************************
* Function Name: DSM_Wakeup
********************************************************************************
*
* Summary:
*  Restores the user configuration and enables the power to the block.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_backup:  The structure field 'enableState' is used to
*  restore the enable state of block after wakeup from sleep mode.
*
*******************************************************************************/
void DSM_Wakeup(void) 
{
    /* Restore the configuration */
    DSM_RestoreConfig();

    /* Enables the component operation */
    if(DSM_backup.enableState != DSM_DISABLED)
    {
        DSM_Enable();
        if((DSM_backup.enableState & DSM_STARTED) != 0u)
        {
            DSM_StartConvert();
        }
    } /* Do nothing if component was disable before */
}


/* [] END OF FILE */
