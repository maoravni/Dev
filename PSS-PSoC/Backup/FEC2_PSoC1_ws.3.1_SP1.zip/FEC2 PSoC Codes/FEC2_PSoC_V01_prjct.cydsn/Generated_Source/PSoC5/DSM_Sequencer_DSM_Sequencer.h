/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <cytypes.h>

#if !defined (DSM_Sequencer_H )
#define DSM_Sequencer_H 

void DSM_Sequencer_Start();
void DSM_Sequencer_Stop();
void DSM_Sequencer_SOC_Delay_SetPeriod(uint8 Period);
void DSM_Sequencer_SOC_Delay_SetCompare(uint8 Compare);


#endif
//[] END OF FILE
