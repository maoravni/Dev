/*******************************************************************************
* File Name: SAR2_Flwr.c
* Version 1.40
*
* Description:
*  This file provides the source code to the API for the SAMPLE/TRACK AND HOLD 
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "SAR2_Flwr.h"

#if (!CY_PSOC5A)
    #if (CYDEV_VARIABLE_VDDA == 1u)
        #include "CyScBoostClk.h"
    #endif /* (CYDEV_VARIABLE_VDDA == 1u) */
#endif /* (!CY_PSOC5A) */

uint8 SAR2_Flwr_initVar = 0u;

/* static SAR2_Flwr_backupStruct  SAR2_Flwr_backup; */
#if (CY_PSOC5A)
    static SAR2_Flwr_backupStruct  SAR2_Flwr_P5backup;
#endif /* CY_PSOC5A */



/*******************************************************************************   
* Function Name: SAR2_Flwr_Init
********************************************************************************
*
* Summary:
*  Initialize component's parameters to the parameters set by user in the 
*  customizer of the component placed onto schematic. Usually called in 
*  SAR2_Flwr_Start().
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void SAR2_Flwr_Init(void) 
{   
    /* Configure SC Block based on selected Sample/Track type */
    #if (SAR2_Flwr_SAMPLE_TRACK_MODE == SAR2_Flwr_SAMPLEANDHOLD) /* Sample and hold mode */
        /* SC Block mode -  - SCxx_CR0[3:1] */
        SAR2_Flwr_CR0_REG = SAR2_Flwr_MODE_SAMPLEANDHOLD;
        
        /* SC Block CR1 */ 
        SAR2_Flwr_CR1_REG = (SAR2_Flwr_COMP_4P35PF  |
                                SAR2_Flwr_GAIN_0DB);
        #if(SAR2_Flwr_SAMPLE_CLOCK_EDGE == SAR2_Flwr_EDGE_POSITIVENEGATIVE)
            SAR2_Flwr_CR1_REG =  SAR2_Flwr_CR1_REG  | SAR2_Flwr_DIV2_DISABLE ;
        #else
            SAR2_Flwr_CR1_REG =  SAR2_Flwr_CR1_REG  | SAR2_Flwr_DIV2_ENABLE ;
        #endif
         
        #if(SAR2_Flwr_VREF_TYPE == SAR2_Flwr_EXTERNAL)
            SAR2_Flwr_CR2_REG = SAR2_Flwr_BIAS_LOW |
                                       SAR2_Flwr_REDC_00 | 
                                       SAR2_Flwr_GNDVREF_DI;
        #else
            SAR2_Flwr_CR2_REG = SAR2_Flwr_BIAS_LOW |
                                       SAR2_Flwr_REDC_00 | 
                                       SAR2_Flwr_GNDVREF_E;
        #endif
    #else
        /* Track and Hold Mode */
        /* SC Block mode -  - SCxx_CR0[3:1] */
        SAR2_Flwr_CR0_REG = SAR2_Flwr_MODE_TRACKANDHOLD; 
        
        /* SC Block CR1 */ 
        SAR2_Flwr_CR1_REG = SAR2_Flwr_COMP_4P35PF  |
                                   SAR2_Flwr_DIV2_ENABLE |
                                   SAR2_Flwr_GAIN_0DB;
                                
        /* SC Block CR2 */
        SAR2_Flwr_CR2_REG = SAR2_Flwr_BIAS_LOW |
                                   SAR2_Flwr_REDC_00 |
                                   SAR2_Flwr_GNDVREF_E;
    #endif /* end if - Sample/Track Type */
    
    /* Enable SC Block clocking */
    SAR2_Flwr_CLK_REG |= SAR2_Flwr_CLK_EN;
    
    /* Set default power */
    SAR2_Flwr_SetPower(SAR2_Flwr_INIT_POWER);
}


/*******************************************************************************   
* Function Name: SAR2_Flwr_Enable
********************************************************************************
*
* Summary:
*  Enables the Sample/Track and Hold block operation
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void SAR2_Flwr_Enable(void) 
{
    /* This is to restore the value of register CR1 and CR2 which is saved 
      in prior to the modifications in stop() API */
    #if (CY_PSOC5A)
        if(SAR2_Flwr_P5backup.enableState == 1u)
        {
            SAR2_Flwr_CR1_REG = SAR2_Flwr_P5backup.scCR1Reg;
            SAR2_Flwr_CR2_REG = SAR2_Flwr_P5backup.scCR2Reg;
            SAR2_Flwr_P5backup.enableState = 0u;
        }
    #endif /* CY_PSOC5A */
    
    /* Enable power to SC block in active mode */
    SAR2_Flwr_PM_ACT_CFG_REG |= SAR2_Flwr_ACT_PWR_EN;
    
    /* Enable power to SC block in Alternative active mode */
    SAR2_Flwr_PM_STBY_CFG_REG |= SAR2_Flwr_STBY_PWR_EN;

    SAR2_Flwr_PUMP_CR1_REG |= SAR2_Flwr_PUMP_CR1_SC_CLKSEL;
    
    #if (!CY_PSOC5A)
        #if (CYDEV_VARIABLE_VDDA == 1u)
            if(CyScPumpEnabled == 1u)
            {
                SAR2_Flwr_BSTCLK_REG &= (uint8)(~SAR2_Flwr_BST_CLK_INDEX_MASK);
                SAR2_Flwr_BSTCLK_REG |= SAR2_Flwr_BST_CLK_EN | CyScBoostClk__INDEX;
                SAR2_Flwr_SC_MISC_REG |= SAR2_Flwr_PUMP_FORCE;
                CyScBoostClk_Start();
            }
            else
            {
                SAR2_Flwr_BSTCLK_REG &= (uint8)(~SAR2_Flwr_BST_CLK_EN);
                SAR2_Flwr_SC_MISC_REG &= (uint8)(~SAR2_Flwr_PUMP_FORCE);
            }
        #endif /* (CYDEV_VARIABLE_VDDA == 1u) */
    #endif /* (!CY_PSOC5A) */
}


/*******************************************************************************
* Function Name: SAR2_Flwr_Start
********************************************************************************
*
* Summary:
*  The start function initializes the Sample and Hold with the default values, 
*  and sets the power to the given level.  A power level of 0, is the same as 
*  executing the stop function.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void SAR2_Flwr_Start(void) 
{
    /* If not Initialized then initialize all required hardware and software */
    if(SAR2_Flwr_initVar == 0u)
    {
        SAR2_Flwr_Init();
        SAR2_Flwr_initVar = 1u;
    }
    SAR2_Flwr_Enable();
}


/*******************************************************************************
* Function Name: SAR2_Flwr_Stop
********************************************************************************
*
* Summary:
*  Powers down amplifier to lowest power state.
*
* Parameters:
*  void
*
* Return:
*  void
*
*******************************************************************************/
void SAR2_Flwr_Stop(void) 
{   
    /* Disble power to the Amp in Active mode template */
    SAR2_Flwr_PM_ACT_CFG_REG &= (uint8)(~SAR2_Flwr_ACT_PWR_EN);

    /* Disble power to the Amp in Alternative Active mode template */
    SAR2_Flwr_PM_STBY_CFG_REG &= (uint8)(~SAR2_Flwr_STBY_PWR_EN);
    
    #if (!CY_PSOC5A)
        #if (CYDEV_VARIABLE_VDDA == 1u)
            SAR2_Flwr_BSTCLK_REG &= (uint8)(~SAR2_Flwr_BST_CLK_EN);
            /* Disable pumps only if there aren't any SC block in use */
            if ((SAR2_Flwr_PM_ACT_CFG_REG & SAR2_Flwr_PM_ACT_CFG_MASK) == 0u)
            {
                SAR2_Flwr_SC_MISC_REG &= (uint8)(~SAR2_Flwr_PUMP_FORCE);
                SAR2_Flwr_PUMP_CR1_REG &= (uint8)(~SAR2_Flwr_PUMP_CR1_SC_CLKSEL);
                CyScBoostClk_Stop();
            }
        #endif /* CYDEV_VARIABLE_VDDA == 1u */
    #endif /* (CY_PSOC3 || CY_PSOC5LP) */
 
    /* This sets Sample and hold in zero current mode and output routes are valid */
    #if (CY_PSOC5A)
        SAR2_Flwr_P5backup.scCR1Reg = SAR2_Flwr_CR1_REG;
        SAR2_Flwr_P5backup.scCR2Reg = SAR2_Flwr_CR2_REG;
        SAR2_Flwr_CR1_REG = 0x00u;
        SAR2_Flwr_CR2_REG = 0x00u;
        SAR2_Flwr_P5backup.enableState = 1u;
    #endif /* CY_PSOC5A */
}


/*******************************************************************************
* Function Name: SAR2_Flwr_SetPower
********************************************************************************
*
* Summary:
*  Set the power of the Sample/Track and Hold.
*
* Parameters:
*  power: Sets power level between (0) and (3) high power
*
* Return:
*  void
*
*******************************************************************************/
void SAR2_Flwr_SetPower(uint8 power) 
{
    uint8 tmpCR;

    /* Sets drive bits in SC Block Control Register 1:  SCxx_CR[1:0] */
    tmpCR = SAR2_Flwr_CR1_REG & (uint8)(~SAR2_Flwr_DRIVE_MASK);
    tmpCR |= (power & SAR2_Flwr_DRIVE_MASK);
    SAR2_Flwr_CR1_REG = tmpCR;
}


/* [] END OF FILE */
