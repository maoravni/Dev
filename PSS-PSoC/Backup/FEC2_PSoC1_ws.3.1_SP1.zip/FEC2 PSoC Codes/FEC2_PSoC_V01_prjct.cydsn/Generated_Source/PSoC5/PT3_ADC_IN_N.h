/*******************************************************************************
* File Name: PT3_ADC_IN_N.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_PT3_ADC_IN_N_H) /* Pins PT3_ADC_IN_N_H */
#define CY_PINS_PT3_ADC_IN_N_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "PT3_ADC_IN_N_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 PT3_ADC_IN_N__PORT == 15 && ((PT3_ADC_IN_N__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    PT3_ADC_IN_N_Write(uint8 value) ;
void    PT3_ADC_IN_N_SetDriveMode(uint8 mode) ;
uint8   PT3_ADC_IN_N_ReadDataReg(void) ;
uint8   PT3_ADC_IN_N_Read(void) ;
uint8   PT3_ADC_IN_N_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define PT3_ADC_IN_N_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define PT3_ADC_IN_N_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define PT3_ADC_IN_N_DM_RES_UP          PIN_DM_RES_UP
#define PT3_ADC_IN_N_DM_RES_DWN         PIN_DM_RES_DWN
#define PT3_ADC_IN_N_DM_OD_LO           PIN_DM_OD_LO
#define PT3_ADC_IN_N_DM_OD_HI           PIN_DM_OD_HI
#define PT3_ADC_IN_N_DM_STRONG          PIN_DM_STRONG
#define PT3_ADC_IN_N_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define PT3_ADC_IN_N_MASK               PT3_ADC_IN_N__MASK
#define PT3_ADC_IN_N_SHIFT              PT3_ADC_IN_N__SHIFT
#define PT3_ADC_IN_N_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define PT3_ADC_IN_N_PS                     (* (reg8 *) PT3_ADC_IN_N__PS)
/* Data Register */
#define PT3_ADC_IN_N_DR                     (* (reg8 *) PT3_ADC_IN_N__DR)
/* Port Number */
#define PT3_ADC_IN_N_PRT_NUM                (* (reg8 *) PT3_ADC_IN_N__PRT) 
/* Connect to Analog Globals */                                                  
#define PT3_ADC_IN_N_AG                     (* (reg8 *) PT3_ADC_IN_N__AG)                       
/* Analog MUX bux enable */
#define PT3_ADC_IN_N_AMUX                   (* (reg8 *) PT3_ADC_IN_N__AMUX) 
/* Bidirectional Enable */                                                        
#define PT3_ADC_IN_N_BIE                    (* (reg8 *) PT3_ADC_IN_N__BIE)
/* Bit-mask for Aliased Register Access */
#define PT3_ADC_IN_N_BIT_MASK               (* (reg8 *) PT3_ADC_IN_N__BIT_MASK)
/* Bypass Enable */
#define PT3_ADC_IN_N_BYP                    (* (reg8 *) PT3_ADC_IN_N__BYP)
/* Port wide control signals */                                                   
#define PT3_ADC_IN_N_CTL                    (* (reg8 *) PT3_ADC_IN_N__CTL)
/* Drive Modes */
#define PT3_ADC_IN_N_DM0                    (* (reg8 *) PT3_ADC_IN_N__DM0) 
#define PT3_ADC_IN_N_DM1                    (* (reg8 *) PT3_ADC_IN_N__DM1)
#define PT3_ADC_IN_N_DM2                    (* (reg8 *) PT3_ADC_IN_N__DM2) 
/* Input Buffer Disable Override */
#define PT3_ADC_IN_N_INP_DIS                (* (reg8 *) PT3_ADC_IN_N__INP_DIS)
/* LCD Common or Segment Drive */
#define PT3_ADC_IN_N_LCD_COM_SEG            (* (reg8 *) PT3_ADC_IN_N__LCD_COM_SEG)
/* Enable Segment LCD */
#define PT3_ADC_IN_N_LCD_EN                 (* (reg8 *) PT3_ADC_IN_N__LCD_EN)
/* Slew Rate Control */
#define PT3_ADC_IN_N_SLW                    (* (reg8 *) PT3_ADC_IN_N__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define PT3_ADC_IN_N_PRTDSI__CAPS_SEL       (* (reg8 *) PT3_ADC_IN_N__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define PT3_ADC_IN_N_PRTDSI__DBL_SYNC_IN    (* (reg8 *) PT3_ADC_IN_N__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define PT3_ADC_IN_N_PRTDSI__OE_SEL0        (* (reg8 *) PT3_ADC_IN_N__PRTDSI__OE_SEL0) 
#define PT3_ADC_IN_N_PRTDSI__OE_SEL1        (* (reg8 *) PT3_ADC_IN_N__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define PT3_ADC_IN_N_PRTDSI__OUT_SEL0       (* (reg8 *) PT3_ADC_IN_N__PRTDSI__OUT_SEL0) 
#define PT3_ADC_IN_N_PRTDSI__OUT_SEL1       (* (reg8 *) PT3_ADC_IN_N__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define PT3_ADC_IN_N_PRTDSI__SYNC_OUT       (* (reg8 *) PT3_ADC_IN_N__PRTDSI__SYNC_OUT) 


#if defined(PT3_ADC_IN_N__INTSTAT)  /* Interrupt Registers */

    #define PT3_ADC_IN_N_INTSTAT                (* (reg8 *) PT3_ADC_IN_N__INTSTAT)
    #define PT3_ADC_IN_N_SNAP                   (* (reg8 *) PT3_ADC_IN_N__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_PT3_ADC_IN_N_H */


/* [] END OF FILE */
