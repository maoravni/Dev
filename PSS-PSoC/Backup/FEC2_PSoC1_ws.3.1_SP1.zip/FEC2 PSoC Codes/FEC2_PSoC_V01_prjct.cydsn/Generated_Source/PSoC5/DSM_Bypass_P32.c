/*******************************************************************************
* File Name: DSM_Bypass_P32.c  
* Version 2.0
*
* Description:
*  This file contains API to enable firmware control of a Pins component.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "cytypes.h"
#include "DSM_Bypass_P32.h"

/* APIs are not generated for P15[7:6] on PSoC 5 */
#if !(CY_PSOC5A &&\
	 DSM_Bypass_P32__PORT == 15 && ((DSM_Bypass_P32__MASK & 0xC0) != 0))


/*******************************************************************************
* Function Name: DSM_Bypass_P32_Write
********************************************************************************
*
* Summary:
*  Assign a new value to the digital port's data output register.  
*
* Parameters:  
*  prtValue:  The value to be assigned to the Digital Port. 
*
* Return: 
*  None
*  
*******************************************************************************/
void DSM_Bypass_P32_Write(uint8 value) 
{
    uint8 staticBits = (DSM_Bypass_P32_DR & (uint8)(~DSM_Bypass_P32_MASK));
    DSM_Bypass_P32_DR = staticBits | ((uint8)(value << DSM_Bypass_P32_SHIFT) & DSM_Bypass_P32_MASK);
}


/*******************************************************************************
* Function Name: DSM_Bypass_P32_SetDriveMode
********************************************************************************
*
* Summary:
*  Change the drive mode on the pins of the port.
* 
* Parameters:  
*  mode:  Change the pins to one of the following drive modes.
*
*  DSM_Bypass_P32_DM_STRONG     Strong Drive 
*  DSM_Bypass_P32_DM_OD_HI      Open Drain, Drives High 
*  DSM_Bypass_P32_DM_OD_LO      Open Drain, Drives Low 
*  DSM_Bypass_P32_DM_RES_UP     Resistive Pull Up 
*  DSM_Bypass_P32_DM_RES_DWN    Resistive Pull Down 
*  DSM_Bypass_P32_DM_RES_UPDWN  Resistive Pull Up/Down 
*  DSM_Bypass_P32_DM_DIG_HIZ    High Impedance Digital 
*  DSM_Bypass_P32_DM_ALG_HIZ    High Impedance Analog 
*
* Return: 
*  None
*
*******************************************************************************/
void DSM_Bypass_P32_SetDriveMode(uint8 mode) 
{
	CyPins_SetPinDriveMode(DSM_Bypass_P32_0, mode);
}


/*******************************************************************************
* Function Name: DSM_Bypass_P32_Read
********************************************************************************
*
* Summary:
*  Read the current value on the pins of the Digital Port in right justified 
*  form.
*
* Parameters:  
*  None
*
* Return: 
*  Returns the current value of the Digital Port as a right justified number
*  
* Note:
*  Macro DSM_Bypass_P32_ReadPS calls this function. 
*  
*******************************************************************************/
uint8 DSM_Bypass_P32_Read(void) 
{
    return (DSM_Bypass_P32_PS & DSM_Bypass_P32_MASK) >> DSM_Bypass_P32_SHIFT;
}


/*******************************************************************************
* Function Name: DSM_Bypass_P32_ReadDataReg
********************************************************************************
*
* Summary:
*  Read the current value assigned to a Digital Port's data output register
*
* Parameters:  
*  None 
*
* Return: 
*  Returns the current value assigned to the Digital Port's data output register
*  
*******************************************************************************/
uint8 DSM_Bypass_P32_ReadDataReg(void) 
{
    return (DSM_Bypass_P32_DR & DSM_Bypass_P32_MASK) >> DSM_Bypass_P32_SHIFT;
}


/* If Interrupts Are Enabled for this Pins component */ 
#if defined(DSM_Bypass_P32_INTSTAT) 

    /*******************************************************************************
    * Function Name: DSM_Bypass_P32_ClearInterrupt
    ********************************************************************************
    * Summary:
    *  Clears any active interrupts attached to port and returns the value of the 
    *  interrupt status register.
    *
    * Parameters:  
    *  None 
    *
    * Return: 
    *  Returns the value of the interrupt status register
    *  
    *******************************************************************************/
    uint8 DSM_Bypass_P32_ClearInterrupt(void) 
    {
        return (DSM_Bypass_P32_INTSTAT & DSM_Bypass_P32_MASK) >> DSM_Bypass_P32_SHIFT;
    }

#endif /* If Interrupts Are Enabled for this Pins component */ 

#endif /* CY_PSOC5A... */

    
/* [] END OF FILE */
