/*******************************************************************************
* File Name: Digital_out_0_5A_CH1.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Digital_out_0_5A_CH1_ALIASES_H) /* Pins Digital_out_0_5A_CH1_ALIASES_H */
#define CY_PINS_Digital_out_0_5A_CH1_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"



/***************************************
*              Constants        
***************************************/
#define Digital_out_0_5A_CH1_0		(Digital_out_0_5A_CH1__0__PC)

#endif /* End Pins Digital_out_0_5A_CH1_ALIASES_H */

/* [] END OF FILE */
