/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <cytypes.h>

#if !defined (CS_DAB_1_H )
#define CS_DAB_1_H 

#define CS_DAB_1_SIZE_OF_PEAKS_DATA_BUFFER	100
#define CS_DAB_1_SIZE_OF_ZERO_DATA_BUFFER	100

#define CS_DAB_1_ZERO_LEVEL				2048
#define CS_DAB_1_DETECT_THRESHOLD		330
		
#define CS_DAB_1_POS_DETECT_THRESHOLD	(CS_DAB_1_ZERO_LEVEL + CS_DAB_1_DETECT_THRESHOLD)
#define CS_DAB_1_NEG_DETECT_THRESHOLD	(CS_DAB_1_ZERO_LEVEL - CS_DAB_1_DETECT_THRESHOLD)

#define CS_DAB_1_PULSE_COUNTER_COMPARE		7
	
/* Main_DMA Configuration for CS1_Detect_DMA */
#define CS_DAB_1_Main_DMA_BYTES_PER_BURST 2
#define CS_DAB_1_Main_DMA_REQUEST_PER_BURST 1
#define CS_DAB_1_Main_DMA_SRC_BASE (CYDEV_PERIPH_BASE)
#define CS_DAB_1_Main_DMA_DST_BASE (CYDEV_PERIPH_BASE)
	
/* Peak_DMA Configuration for CS1_Detect_DMA */
#define CS_DAB_1_Peak_DMA_BYTES_PER_BURST 2
#define CS_DAB_1_Peak_DMA_REQUEST_PER_BURST 1
#define CS_DAB_1_Peak_DMA_SRC_BASE (CYDEV_PERIPH_BASE)
#define CS_DAB_1_Peak_DMA_DST_BASE (CYDEV_SRAM_BASE)
	
/* Zero_DMA Configuration for CS1_Detect_DMA */	
#define CS_DAB_1_Zero_DMA_BYTES_PER_BURST 2
#define CS_DAB_1_Zero_DMA_REQUEST_PER_BURST 1
#define CS_DAB_1_Zero_DMA_SRC_BASE (CYDEV_PERIPH_BASE)
#define CS_DAB_1_Zero_DMA_DST_BASE (CYDEV_SRAM_BASE)	

/* Store_Peak_DMA Configuration for CS1_Detect_DMA */
#define CS_DAB_1_Store_Peak_DMA_REQUEST_PER_BURST 0
#define CS_DAB_1_Store_Peak_DMA_SRC_BASE (CYDEV_SRAM_BASE)	

/* Store_Zero_DMA Configuration for CS1_Detect_DMA */
#define CS_DAB_1_Store_Zero_DMA_REQUEST_PER_BURST 0
#define CS_DAB_1_Store_Zero_DMA_SRC_BASE (CYDEV_SRAM_BASE)
	
extern int16 CS_DAB_1_Peak_Data[CS_DAB_1_SIZE_OF_PEAKS_DATA_BUFFER];
extern int16 CS_DAB_1_Zero_Data[CS_DAB_1_SIZE_OF_ZERO_DATA_BUFFER];

extern uint8 CS_DAB_1_P_Data_Ready;
extern uint8 CS_DAB_1_Z_Data_Ready;

extern uint8 CS_DAB_1_CS_ON_Counter;


void CS_DAB_1_Start();
void CS_DAB_1_Stop();

void CS_DAB_1_DMAs_Config();
void CS_DAB_1_Peak_DMA_Enable();
void CS_DAB_1_Zero_DMA_Enable();

void CS_DAB_1_Calibrate(uint16 CS_DAB_1_Zero_Level, uint16 CS_DAB_1_Detect_Thrshld);

#endif
/* [] END OF FILE */
