/*
 * version.h
 *
 *  Created on: 27 Oct 2013
 */

#ifndef VERSION_H_
#define VERSION_H_

#define M_FEC_FIRMWARE_VERSION_MAJOR 1
#define M_FEC_FIRMWARE_VERSION_MINOR 0
#define M_FEC_FIRMWARE_VERSION_BUILD 0
#define M_FEC_FIRMWARE_VERSION_REVISION 190

#define M_ICD_VERSION_MAJOR 				2
#define M_ICD_VERSION_MINOR 				1
#define M_ICD_VERSION_BUILD 				0
#define M_ICD_VERSION_REVISION 				8

#endif /* VERSION_H_ */
