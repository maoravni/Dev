/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <cytypes.h>

#if !defined (OTSM_1_H )
#define OTSM_1_H 
#define OTSM_1_OVER_TEMP_MASK 	0x55 //0b01010101
#define	OTSM_1_ABS_OVER_TEMP_MASK 0xAA //0b10101010
uint8 OTSM_1_Check_Temperature( float Temperature, uint8 SensNo);

#endif
/* [] END OF FILE */
