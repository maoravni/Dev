/*******************************************************************************
* File Name: DSM_Sequencer_SOC_Delay_PM.c
* Version 3.10
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DSM_Sequencer_SOC_Delay.h"

static DSM_Sequencer_SOC_Delay_backupStruct DSM_Sequencer_SOC_Delay_backup;


/*******************************************************************************
* Function Name: DSM_Sequencer_SOC_Delay_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_Sequencer_SOC_Delay_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void DSM_Sequencer_SOC_Delay_SaveConfig(void) 
{

    #if(!DSM_Sequencer_SOC_Delay_UsingFixedFunction)
        #if(!DSM_Sequencer_SOC_Delay_PWMModeIsCenterAligned)
            DSM_Sequencer_SOC_Delay_backup.PWMPeriod = DSM_Sequencer_SOC_Delay_ReadPeriod();
        #endif /* (!DSM_Sequencer_SOC_Delay_PWMModeIsCenterAligned) */
        DSM_Sequencer_SOC_Delay_backup.PWMUdb = DSM_Sequencer_SOC_Delay_ReadCounter();
        #if (DSM_Sequencer_SOC_Delay_UseStatus)
            DSM_Sequencer_SOC_Delay_backup.InterruptMaskValue = DSM_Sequencer_SOC_Delay_STATUS_MASK;
        #endif /* (DSM_Sequencer_SOC_Delay_UseStatus) */

        #if(DSM_Sequencer_SOC_Delay_DeadBandMode == DSM_Sequencer_SOC_Delay__B_PWM__DBM_256_CLOCKS || \
            DSM_Sequencer_SOC_Delay_DeadBandMode == DSM_Sequencer_SOC_Delay__B_PWM__DBM_2_4_CLOCKS)
            DSM_Sequencer_SOC_Delay_backup.PWMdeadBandValue = DSM_Sequencer_SOC_Delay_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(DSM_Sequencer_SOC_Delay_KillModeMinTime)
             DSM_Sequencer_SOC_Delay_backup.PWMKillCounterPeriod = DSM_Sequencer_SOC_Delay_ReadKillTime();
        #endif /* (DSM_Sequencer_SOC_Delay_KillModeMinTime) */

        #if(DSM_Sequencer_SOC_Delay_UseControl)
            DSM_Sequencer_SOC_Delay_backup.PWMControlRegister = DSM_Sequencer_SOC_Delay_ReadControlRegister();
        #endif /* (DSM_Sequencer_SOC_Delay_UseControl) */
    #endif  /* (!DSM_Sequencer_SOC_Delay_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DSM_Sequencer_SOC_Delay_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_Sequencer_SOC_Delay_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void DSM_Sequencer_SOC_Delay_RestoreConfig(void) 
{
        #if(!DSM_Sequencer_SOC_Delay_UsingFixedFunction)
            #if(!DSM_Sequencer_SOC_Delay_PWMModeIsCenterAligned)
                DSM_Sequencer_SOC_Delay_WritePeriod(DSM_Sequencer_SOC_Delay_backup.PWMPeriod);
            #endif /* (!DSM_Sequencer_SOC_Delay_PWMModeIsCenterAligned) */

            DSM_Sequencer_SOC_Delay_WriteCounter(DSM_Sequencer_SOC_Delay_backup.PWMUdb);

            #if (DSM_Sequencer_SOC_Delay_UseStatus)
                DSM_Sequencer_SOC_Delay_STATUS_MASK = DSM_Sequencer_SOC_Delay_backup.InterruptMaskValue;
            #endif /* (DSM_Sequencer_SOC_Delay_UseStatus) */

            #if(DSM_Sequencer_SOC_Delay_DeadBandMode == DSM_Sequencer_SOC_Delay__B_PWM__DBM_256_CLOCKS || \
                DSM_Sequencer_SOC_Delay_DeadBandMode == DSM_Sequencer_SOC_Delay__B_PWM__DBM_2_4_CLOCKS)
                DSM_Sequencer_SOC_Delay_WriteDeadTime(DSM_Sequencer_SOC_Delay_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(DSM_Sequencer_SOC_Delay_KillModeMinTime)
                DSM_Sequencer_SOC_Delay_WriteKillTime(DSM_Sequencer_SOC_Delay_backup.PWMKillCounterPeriod);
            #endif /* (DSM_Sequencer_SOC_Delay_KillModeMinTime) */

            #if(DSM_Sequencer_SOC_Delay_UseControl)
                DSM_Sequencer_SOC_Delay_WriteControlRegister(DSM_Sequencer_SOC_Delay_backup.PWMControlRegister);
            #endif /* (DSM_Sequencer_SOC_Delay_UseControl) */
        #endif  /* (!DSM_Sequencer_SOC_Delay_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: DSM_Sequencer_SOC_Delay_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_Sequencer_SOC_Delay_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void DSM_Sequencer_SOC_Delay_Sleep(void) 
{
    #if(DSM_Sequencer_SOC_Delay_UseControl)
        if(DSM_Sequencer_SOC_Delay_CTRL_ENABLE == (DSM_Sequencer_SOC_Delay_CONTROL & DSM_Sequencer_SOC_Delay_CTRL_ENABLE))
        {
            /*Component is enabled */
            DSM_Sequencer_SOC_Delay_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            DSM_Sequencer_SOC_Delay_backup.PWMEnableState = 0u;
        }
    #endif /* (DSM_Sequencer_SOC_Delay_UseControl) */

    /* Stop component */
    DSM_Sequencer_SOC_Delay_Stop();

    /* Save registers configuration */
    DSM_Sequencer_SOC_Delay_SaveConfig();
}


/*******************************************************************************
* Function Name: DSM_Sequencer_SOC_Delay_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DSM_Sequencer_SOC_Delay_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void DSM_Sequencer_SOC_Delay_Wakeup(void) 
{
     /* Restore registers values */
    DSM_Sequencer_SOC_Delay_RestoreConfig();

    if(DSM_Sequencer_SOC_Delay_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        DSM_Sequencer_SOC_Delay_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
