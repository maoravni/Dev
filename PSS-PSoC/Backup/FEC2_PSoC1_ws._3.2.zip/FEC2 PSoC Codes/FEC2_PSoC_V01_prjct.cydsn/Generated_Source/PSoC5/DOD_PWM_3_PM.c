/*******************************************************************************
* File Name: DOD_PWM_3_PM.c
* Version 3.10
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DOD_PWM_3.h"

static DOD_PWM_3_backupStruct DOD_PWM_3_backup;


/*******************************************************************************
* Function Name: DOD_PWM_3_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_3_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void DOD_PWM_3_SaveConfig(void) 
{

    #if(!DOD_PWM_3_UsingFixedFunction)
        #if(!DOD_PWM_3_PWMModeIsCenterAligned)
            DOD_PWM_3_backup.PWMPeriod = DOD_PWM_3_ReadPeriod();
        #endif /* (!DOD_PWM_3_PWMModeIsCenterAligned) */
        DOD_PWM_3_backup.PWMUdb = DOD_PWM_3_ReadCounter();
        #if (DOD_PWM_3_UseStatus)
            DOD_PWM_3_backup.InterruptMaskValue = DOD_PWM_3_STATUS_MASK;
        #endif /* (DOD_PWM_3_UseStatus) */

        #if(DOD_PWM_3_DeadBandMode == DOD_PWM_3__B_PWM__DBM_256_CLOCKS || \
            DOD_PWM_3_DeadBandMode == DOD_PWM_3__B_PWM__DBM_2_4_CLOCKS)
            DOD_PWM_3_backup.PWMdeadBandValue = DOD_PWM_3_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(DOD_PWM_3_KillModeMinTime)
             DOD_PWM_3_backup.PWMKillCounterPeriod = DOD_PWM_3_ReadKillTime();
        #endif /* (DOD_PWM_3_KillModeMinTime) */

        #if(DOD_PWM_3_UseControl)
            DOD_PWM_3_backup.PWMControlRegister = DOD_PWM_3_ReadControlRegister();
        #endif /* (DOD_PWM_3_UseControl) */
    #endif  /* (!DOD_PWM_3_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DOD_PWM_3_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_3_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void DOD_PWM_3_RestoreConfig(void) 
{
        #if(!DOD_PWM_3_UsingFixedFunction)
            #if(!DOD_PWM_3_PWMModeIsCenterAligned)
                DOD_PWM_3_WritePeriod(DOD_PWM_3_backup.PWMPeriod);
            #endif /* (!DOD_PWM_3_PWMModeIsCenterAligned) */

            DOD_PWM_3_WriteCounter(DOD_PWM_3_backup.PWMUdb);

            #if (DOD_PWM_3_UseStatus)
                DOD_PWM_3_STATUS_MASK = DOD_PWM_3_backup.InterruptMaskValue;
            #endif /* (DOD_PWM_3_UseStatus) */

            #if(DOD_PWM_3_DeadBandMode == DOD_PWM_3__B_PWM__DBM_256_CLOCKS || \
                DOD_PWM_3_DeadBandMode == DOD_PWM_3__B_PWM__DBM_2_4_CLOCKS)
                DOD_PWM_3_WriteDeadTime(DOD_PWM_3_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(DOD_PWM_3_KillModeMinTime)
                DOD_PWM_3_WriteKillTime(DOD_PWM_3_backup.PWMKillCounterPeriod);
            #endif /* (DOD_PWM_3_KillModeMinTime) */

            #if(DOD_PWM_3_UseControl)
                DOD_PWM_3_WriteControlRegister(DOD_PWM_3_backup.PWMControlRegister);
            #endif /* (DOD_PWM_3_UseControl) */
        #endif  /* (!DOD_PWM_3_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: DOD_PWM_3_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_3_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void DOD_PWM_3_Sleep(void) 
{
    #if(DOD_PWM_3_UseControl)
        if(DOD_PWM_3_CTRL_ENABLE == (DOD_PWM_3_CONTROL & DOD_PWM_3_CTRL_ENABLE))
        {
            /*Component is enabled */
            DOD_PWM_3_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            DOD_PWM_3_backup.PWMEnableState = 0u;
        }
    #endif /* (DOD_PWM_3_UseControl) */

    /* Stop component */
    DOD_PWM_3_Stop();

    /* Save registers configuration */
    DOD_PWM_3_SaveConfig();
}


/*******************************************************************************
* Function Name: DOD_PWM_3_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_3_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void DOD_PWM_3_Wakeup(void) 
{
     /* Restore registers values */
    DOD_PWM_3_RestoreConfig();

    if(DOD_PWM_3_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        DOD_PWM_3_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
