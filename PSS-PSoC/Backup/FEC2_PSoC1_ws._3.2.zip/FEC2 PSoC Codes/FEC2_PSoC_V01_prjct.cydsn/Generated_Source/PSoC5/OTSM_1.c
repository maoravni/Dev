/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>


uint8 OTSM_1_Check_Temperature( float Temperature, uint8 SensNo)
{
	static uint8 OTSM_1_QualiCntr[4] = {50,50,50,50};
	static uint8 OTSM_1_SoftControlReg = 0x00;
	static uint8 OTSM_1_Status = 0x00;
	
	switch(SensNo)
	{
		/* PT100 1 */
		case 0:
		{
			/* Stop Heat Alarm 1 */
			if (Temperature >= 370)
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x01);
			}
			else
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x01);
			}
			
			/* Safety Relay Alarm 1 */
			if (Temperature >= 420)
			{
				if (!OTSM_1_QualiCntr[0])
				{
					OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x02);
					//OTSM_1_QualiCntr[0] = 50;
				}
				OTSM_1_QualiCntr[0]--;
			}
			else
			{
				OTSM_1_QualiCntr[0] = 50;
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x02);
			}			

			break;
		}
		
		/* PT100 2 */
		case 1:
		{
			/* Stop Heat Alarm 2 */
			if (Temperature >= 370)
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x04);
			}
			else
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x04);
			}
			
			/* Safety Relay Alarm 2 */
			if (Temperature >= 420)
			{
				if (!OTSM_1_QualiCntr[1])
				{
					OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x08);
					//OTSM_1_QualiCntr[1] = 50;
				}
				OTSM_1_QualiCntr[1]--;
			}
			else
			{
				OTSM_1_QualiCntr[1] = 50;
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x08);
			}			
			break;
		}
		
		/* PT100 3 */
		case 2:
		{
			/* Stop Heat Alarm 3 */
			if (Temperature >= 370)
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x10);
			}
			else
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x10);
			}
			/* Safety Relay Alarm 3 */
			if (Temperature >= 420)
			{
				if (!OTSM_1_QualiCntr[2])
				{
					OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x20);
					//OTSM_1_QualiCntr[2] = 50;
				}
				OTSM_1_QualiCntr[2]--;
			}
			else
			{
				OTSM_1_QualiCntr[2] = 50;
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x20);
			}			
			break;
		}
		
		/* PT100 4 */
		case 3:
		{
			/* Stop Heat Alarm 4 */
			if (Temperature >= 370)
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x40);
			}
			else
			{
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x40);
			}
			
			/* Safety Relay Alarm 4 */
			if (Temperature >= 420)
			{
				if (!OTSM_1_QualiCntr[3])
				{				
					OTSM_1_SoftControlReg = OTSM_1_SoftControlReg | (0x80);
					//OTSM_1_QualiCntr[3] = 50;
				}
				OTSM_1_QualiCntr[3]--;
			}
			else
			{
				OTSM_1_QualiCntr[3] = 50;
				OTSM_1_SoftControlReg = OTSM_1_SoftControlReg & (~0x80);
			}			
			break;
		}
		default:
		{
		
			break;
		}
	}
	// Check if there is over temperature
	if(OTSM_1_SoftControlReg & OTSM_1_OVER_TEMP_MASK)
	{
		OTSM_1_Status = OTSM_1_Status | (0x01);	
	}
	else
	{
		OTSM_1_Status = OTSM_1_Status & (~0x01);		
	}
	// Check if there is absolute over temperature
	if(OTSM_1_SoftControlReg & OTSM_1_ABS_OVER_TEMP_MASK)
	{
		OTSM_1_Status = OTSM_1_Status | (0x02);	
	}
	else
	{
		OTSM_1_Status = OTSM_1_Status & (~0x02);		
	}
	return(OTSM_1_Status);
}

/* [] END OF FILE */
