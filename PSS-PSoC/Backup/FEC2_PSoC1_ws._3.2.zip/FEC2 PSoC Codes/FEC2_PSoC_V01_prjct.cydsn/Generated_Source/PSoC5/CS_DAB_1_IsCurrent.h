/*******************************************************************************
* File Name: CS_DAB_1_IsCurrent.h
* Version 3.10
*
* Description:
*  Contains the prototypes and constants for the functions available to the
*  PWM user module.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
********************************************************************************/

#if !defined(CY_PWM_CS_DAB_1_IsCurrent_H)
#define CY_PWM_CS_DAB_1_IsCurrent_H

#include "cytypes.h"
#include "cyfitter.h"
#include "CyLib.h" /* For CyEnterCriticalSection() and CyExitCriticalSection() functions */

extern uint8 CS_DAB_1_IsCurrent_initVar;


/***************************************
* Conditional Compilation Parameters
***************************************/
#define CS_DAB_1_IsCurrent_Resolution                     (16u)
#define CS_DAB_1_IsCurrent_UsingFixedFunction             (0u)
#define CS_DAB_1_IsCurrent_DeadBandMode                   (0u)
#define CS_DAB_1_IsCurrent_KillModeMinTime                (0u)
#define CS_DAB_1_IsCurrent_KillMode                       (0u)
#define CS_DAB_1_IsCurrent_PWMMode                        (1u)
#define CS_DAB_1_IsCurrent_PWMModeIsCenterAligned         (0u)
#define CS_DAB_1_IsCurrent_DeadBandUsed                   (0u)
#define CS_DAB_1_IsCurrent_DeadBand2_4                    (0u)

#if !defined(CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__REMOVED)
    #define CS_DAB_1_IsCurrent_UseStatus                  (1u)
#else
    #define CS_DAB_1_IsCurrent_UseStatus                  (0u)
#endif /* !defined(CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__REMOVED) */

#if !defined(CS_DAB_1_IsCurrent_PWMUDB_genblk1_ctrlreg__REMOVED)
    #define CS_DAB_1_IsCurrent_UseControl                 (1u)
#else
    #define CS_DAB_1_IsCurrent_UseControl                 (0u)
#endif /* !defined(CS_DAB_1_IsCurrent_PWMUDB_genblk1_ctrlreg__REMOVED) */

#define CS_DAB_1_IsCurrent_UseOneCompareMode              (0u)
#define CS_DAB_1_IsCurrent_MinimumKillTime                (1u)
#define CS_DAB_1_IsCurrent_EnableMode                     (0u)

#define CS_DAB_1_IsCurrent_CompareMode1SW                 (0u)
#define CS_DAB_1_IsCurrent_CompareMode2SW                 (0u)

/* Check to see if required defines such as CY_PSOC5LP are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5LP)
    #error Component PWM_v3_10 requires cy_boot v3.0 or later
#endif /* (CY_ PSOC5LP) */

/* Use Kill Mode Enumerated Types */
#define CS_DAB_1_IsCurrent__B_PWM__DISABLED 0
#define CS_DAB_1_IsCurrent__B_PWM__ASYNCHRONOUS 1
#define CS_DAB_1_IsCurrent__B_PWM__SINGLECYCLE 2
#define CS_DAB_1_IsCurrent__B_PWM__LATCHED 3
#define CS_DAB_1_IsCurrent__B_PWM__MINTIME 4


/* Use Dead Band Mode Enumerated Types */
#define CS_DAB_1_IsCurrent__B_PWM__DBMDISABLED 0
#define CS_DAB_1_IsCurrent__B_PWM__DBM_2_4_CLOCKS 1
#define CS_DAB_1_IsCurrent__B_PWM__DBM_256_CLOCKS 2


/* Used PWM Mode Enumerated Types */
#define CS_DAB_1_IsCurrent__B_PWM__ONE_OUTPUT 0
#define CS_DAB_1_IsCurrent__B_PWM__TWO_OUTPUTS 1
#define CS_DAB_1_IsCurrent__B_PWM__DUAL_EDGE 2
#define CS_DAB_1_IsCurrent__B_PWM__CENTER_ALIGN 3
#define CS_DAB_1_IsCurrent__B_PWM__DITHER 5
#define CS_DAB_1_IsCurrent__B_PWM__HARDWARESELECT 4


/* Used PWM Compare Mode Enumerated Types */
#define CS_DAB_1_IsCurrent__B_PWM__LESS_THAN 1
#define CS_DAB_1_IsCurrent__B_PWM__LESS_THAN_OR_EQUAL 2
#define CS_DAB_1_IsCurrent__B_PWM__GREATER_THAN 3
#define CS_DAB_1_IsCurrent__B_PWM__GREATER_THAN_OR_EQUAL_TO 4
#define CS_DAB_1_IsCurrent__B_PWM__EQUAL 0
#define CS_DAB_1_IsCurrent__B_PWM__FIRMWARE 5



/***************************************
* Data Struct Definition
***************************************/


/**************************************************************************
 * Sleep Wakeup Backup structure for PWM Component
 *************************************************************************/
typedef struct
{

    uint8 PWMEnableState;

    #if(!CS_DAB_1_IsCurrent_UsingFixedFunction)
        uint16 PWMUdb;               /* PWM Current Counter value  */
        #if(!CS_DAB_1_IsCurrent_PWMModeIsCenterAligned)
            uint16 PWMPeriod;
        #endif /* (!CS_DAB_1_IsCurrent_PWMModeIsCenterAligned) */
        #if (CS_DAB_1_IsCurrent_UseStatus)
            uint8 InterruptMaskValue;   /* PWM Current Interrupt Mask */
        #endif /* (CS_DAB_1_IsCurrent_UseStatus) */

        /* Backup for Deadband parameters */
        #if(CS_DAB_1_IsCurrent_DeadBandMode == CS_DAB_1_IsCurrent__B_PWM__DBM_256_CLOCKS || \
            CS_DAB_1_IsCurrent_DeadBandMode == CS_DAB_1_IsCurrent__B_PWM__DBM_2_4_CLOCKS)
            uint8 PWMdeadBandValue; /* Dead Band Counter Current Value */
        #endif /* deadband count is either 2-4 clocks or 256 clocks */

        /* Backup Kill Mode Counter*/
        #if(CS_DAB_1_IsCurrent_KillModeMinTime)
            uint8 PWMKillCounterPeriod; /* Kill Mode period value */
        #endif /* (CS_DAB_1_IsCurrent_KillModeMinTime) */

        /* Backup control register */
        #if(CS_DAB_1_IsCurrent_UseControl)
            uint8 PWMControlRegister; /* PWM Control Register value */
        #endif /* (CS_DAB_1_IsCurrent_UseControl) */

    #endif /* (!CS_DAB_1_IsCurrent_UsingFixedFunction) */

}CS_DAB_1_IsCurrent_backupStruct;


/***************************************
*        Function Prototypes
 **************************************/

void    CS_DAB_1_IsCurrent_Start(void) ;
void    CS_DAB_1_IsCurrent_Stop(void) ;

#if (CS_DAB_1_IsCurrent_UseStatus || CS_DAB_1_IsCurrent_UsingFixedFunction)
    void  CS_DAB_1_IsCurrent_SetInterruptMode(uint8 interruptMode) ;
    uint8 CS_DAB_1_IsCurrent_ReadStatusRegister(void) ;
#endif /* (CS_DAB_1_IsCurrent_UseStatus || CS_DAB_1_IsCurrent_UsingFixedFunction) */

#define CS_DAB_1_IsCurrent_GetInterruptSource() CS_DAB_1_IsCurrent_ReadStatusRegister()

#if (CS_DAB_1_IsCurrent_UseControl)
    uint8 CS_DAB_1_IsCurrent_ReadControlRegister(void) ;
    void  CS_DAB_1_IsCurrent_WriteControlRegister(uint8 control)
          ;
#endif /* (CS_DAB_1_IsCurrent_UseControl) */

#if (CS_DAB_1_IsCurrent_UseOneCompareMode)
   #if (CS_DAB_1_IsCurrent_CompareMode1SW)
       void    CS_DAB_1_IsCurrent_SetCompareMode(uint8 comparemode)
               ;
   #endif /* (CS_DAB_1_IsCurrent_CompareMode1SW) */
#else
    #if (CS_DAB_1_IsCurrent_CompareMode1SW)
        void    CS_DAB_1_IsCurrent_SetCompareMode1(uint8 comparemode)
                ;
    #endif /* (CS_DAB_1_IsCurrent_CompareMode1SW) */
    #if (CS_DAB_1_IsCurrent_CompareMode2SW)
        void    CS_DAB_1_IsCurrent_SetCompareMode2(uint8 comparemode)
                ;
    #endif /* (CS_DAB_1_IsCurrent_CompareMode2SW) */
#endif /* (CS_DAB_1_IsCurrent_UseOneCompareMode) */

#if (!CS_DAB_1_IsCurrent_UsingFixedFunction)
    uint16   CS_DAB_1_IsCurrent_ReadCounter(void) ;
    uint16 CS_DAB_1_IsCurrent_ReadCapture(void) ;

    #if (CS_DAB_1_IsCurrent_UseStatus)
            void CS_DAB_1_IsCurrent_ClearFIFO(void) ;
    #endif /* (CS_DAB_1_IsCurrent_UseStatus) */

    void    CS_DAB_1_IsCurrent_WriteCounter(uint16 counter)
            ;
#endif /* (!CS_DAB_1_IsCurrent_UsingFixedFunction) */

void    CS_DAB_1_IsCurrent_WritePeriod(uint16 period)
        ;
uint16 CS_DAB_1_IsCurrent_ReadPeriod(void) ;

#if (CS_DAB_1_IsCurrent_UseOneCompareMode)
    void    CS_DAB_1_IsCurrent_WriteCompare(uint16 compare)
            ;
    uint16 CS_DAB_1_IsCurrent_ReadCompare(void) ;
#else
    void    CS_DAB_1_IsCurrent_WriteCompare1(uint16 compare)
            ;
    uint16 CS_DAB_1_IsCurrent_ReadCompare1(void) ;
    void    CS_DAB_1_IsCurrent_WriteCompare2(uint16 compare)
            ;
    uint16 CS_DAB_1_IsCurrent_ReadCompare2(void) ;
#endif /* (CS_DAB_1_IsCurrent_UseOneCompareMode) */


#if (CS_DAB_1_IsCurrent_DeadBandUsed)
    void    CS_DAB_1_IsCurrent_WriteDeadTime(uint8 deadtime) ;
    uint8   CS_DAB_1_IsCurrent_ReadDeadTime(void) ;
#endif /* (CS_DAB_1_IsCurrent_DeadBandUsed) */

#if ( CS_DAB_1_IsCurrent_KillModeMinTime)
    void CS_DAB_1_IsCurrent_WriteKillTime(uint8 killtime) ;
    uint8 CS_DAB_1_IsCurrent_ReadKillTime(void) ;
#endif /* ( CS_DAB_1_IsCurrent_KillModeMinTime) */

void CS_DAB_1_IsCurrent_Init(void) ;
void CS_DAB_1_IsCurrent_Enable(void) ;
void CS_DAB_1_IsCurrent_Sleep(void) ;
void CS_DAB_1_IsCurrent_Wakeup(void) ;
void CS_DAB_1_IsCurrent_SaveConfig(void) ;
void CS_DAB_1_IsCurrent_RestoreConfig(void) ;


/***************************************
*         Initialization Values
**************************************/
#define CS_DAB_1_IsCurrent_INIT_PERIOD_VALUE          (4095u)
#define CS_DAB_1_IsCurrent_INIT_COMPARE_VALUE1        (2212u)
#define CS_DAB_1_IsCurrent_INIT_COMPARE_VALUE2        (1884u)
#define CS_DAB_1_IsCurrent_INIT_INTERRUPTS_MODE       (uint8)(((uint8)(0u <<   \
                                                    CS_DAB_1_IsCurrent_STATUS_TC_INT_EN_MASK_SHIFT)) | \
                                                    (uint8)((uint8)(0u <<  \
                                                    CS_DAB_1_IsCurrent_STATUS_CMP2_INT_EN_MASK_SHIFT)) | \
                                                    (uint8)((uint8)(0u <<  \
                                                    CS_DAB_1_IsCurrent_STATUS_CMP1_INT_EN_MASK_SHIFT )) | \
                                                    (uint8)((uint8)(0u <<  \
                                                    CS_DAB_1_IsCurrent_STATUS_KILL_INT_EN_MASK_SHIFT )))
#define CS_DAB_1_IsCurrent_DEFAULT_COMPARE2_MODE      (uint8)((uint8)1u <<  CS_DAB_1_IsCurrent_CTRL_CMPMODE2_SHIFT)
#define CS_DAB_1_IsCurrent_DEFAULT_COMPARE1_MODE      (uint8)((uint8)3u <<  CS_DAB_1_IsCurrent_CTRL_CMPMODE1_SHIFT)
#define CS_DAB_1_IsCurrent_INIT_DEAD_TIME             (1u)


/********************************
*         Registers
******************************** */

#if (CS_DAB_1_IsCurrent_UsingFixedFunction)
   #define CS_DAB_1_IsCurrent_PERIOD_LSB              (*(reg16 *) CS_DAB_1_IsCurrent_PWMHW__PER0)
   #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR          ( (reg16 *) CS_DAB_1_IsCurrent_PWMHW__PER0)
   #define CS_DAB_1_IsCurrent_COMPARE1_LSB            (*(reg16 *) CS_DAB_1_IsCurrent_PWMHW__CNT_CMP0)
   #define CS_DAB_1_IsCurrent_COMPARE1_LSB_PTR        ( (reg16 *) CS_DAB_1_IsCurrent_PWMHW__CNT_CMP0)
   #define CS_DAB_1_IsCurrent_COMPARE2_LSB            (0x00u)
   #define CS_DAB_1_IsCurrent_COMPARE2_LSB_PTR        (0x00u)
   #define CS_DAB_1_IsCurrent_COUNTER_LSB             (*(reg16 *) CS_DAB_1_IsCurrent_PWMHW__CNT_CMP0)
   #define CS_DAB_1_IsCurrent_COUNTER_LSB_PTR         ( (reg16 *) CS_DAB_1_IsCurrent_PWMHW__CNT_CMP0)
   #define CS_DAB_1_IsCurrent_CAPTURE_LSB             (*(reg16 *) CS_DAB_1_IsCurrent_PWMHW__CAP0)
   #define CS_DAB_1_IsCurrent_CAPTURE_LSB_PTR         ( (reg16 *) CS_DAB_1_IsCurrent_PWMHW__CAP0)
   #define CS_DAB_1_IsCurrent_RT1                     (*(reg8 *)  CS_DAB_1_IsCurrent_PWMHW__RT1)
   #define CS_DAB_1_IsCurrent_RT1_PTR                 ( (reg8 *)  CS_DAB_1_IsCurrent_PWMHW__RT1)

#else
   #if (CS_DAB_1_IsCurrent_Resolution == 8u) /* 8bit - PWM */

       #if(CS_DAB_1_IsCurrent_PWMModeIsCenterAligned)
           #define CS_DAB_1_IsCurrent_PERIOD_LSB      (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
           #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR  ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
       #else
           #define CS_DAB_1_IsCurrent_PERIOD_LSB      (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F0_REG)
           #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR  ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F0_REG)
       #endif /* (CS_DAB_1_IsCurrent_PWMModeIsCenterAligned) */

       #define CS_DAB_1_IsCurrent_COMPARE1_LSB        (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D0_REG)
       #define CS_DAB_1_IsCurrent_COMPARE1_LSB_PTR    ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D0_REG)
       #define CS_DAB_1_IsCurrent_COMPARE2_LSB        (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
       #define CS_DAB_1_IsCurrent_COMPARE2_LSB_PTR    ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
       #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB      (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A1_REG)
       #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB_PTR  ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A1_REG)
       #define CS_DAB_1_IsCurrent_COUNTER_LSB         (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A0_REG)
       #define CS_DAB_1_IsCurrent_COUNTER_LSB_PTR     ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A0_REG)
       #define CS_DAB_1_IsCurrent_CAPTURE_LSB         (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F1_REG)
       #define CS_DAB_1_IsCurrent_CAPTURE_LSB_PTR     ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F1_REG)

   #else
        #if(CY_PSOC3) /* 8-bit address space */
            #if(CS_DAB_1_IsCurrent_PWMModeIsCenterAligned)
               #define CS_DAB_1_IsCurrent_PERIOD_LSB      (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
               #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR  ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
            #else
               #define CS_DAB_1_IsCurrent_PERIOD_LSB      (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F0_REG)
               #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR  ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F0_REG)
            #endif /* (CS_DAB_1_IsCurrent_PWMModeIsCenterAligned) */

            #define CS_DAB_1_IsCurrent_COMPARE1_LSB       (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D0_REG)
            #define CS_DAB_1_IsCurrent_COMPARE1_LSB_PTR   ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D0_REG)
            #define CS_DAB_1_IsCurrent_COMPARE2_LSB       (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
            #define CS_DAB_1_IsCurrent_COMPARE2_LSB_PTR   ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__D1_REG)
            #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB     (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A1_REG)
            #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB_PTR ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A1_REG)
            #define CS_DAB_1_IsCurrent_COUNTER_LSB        (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A0_REG)
            #define CS_DAB_1_IsCurrent_COUNTER_LSB_PTR    ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A0_REG)
            #define CS_DAB_1_IsCurrent_CAPTURE_LSB        (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F1_REG)
            #define CS_DAB_1_IsCurrent_CAPTURE_LSB_PTR    ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__F1_REG)
        #else
            #if(CS_DAB_1_IsCurrent_PWMModeIsCenterAligned)
               #define CS_DAB_1_IsCurrent_PERIOD_LSB      (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_D1_REG)
               #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR  ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_D1_REG)
            #else
               #define CS_DAB_1_IsCurrent_PERIOD_LSB      (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_F0_REG)
               #define CS_DAB_1_IsCurrent_PERIOD_LSB_PTR  ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_F0_REG)
            #endif /* (CS_DAB_1_IsCurrent_PWMModeIsCenterAligned) */

            #define CS_DAB_1_IsCurrent_COMPARE1_LSB       (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_D0_REG)
            #define CS_DAB_1_IsCurrent_COMPARE1_LSB_PTR   ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_D0_REG)
            #define CS_DAB_1_IsCurrent_COMPARE2_LSB       (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_D1_REG)
            #define CS_DAB_1_IsCurrent_COMPARE2_LSB_PTR   ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_D1_REG)
            #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB     (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_A1_REG)
            #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB_PTR ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_A1_REG)
            #define CS_DAB_1_IsCurrent_COUNTER_LSB        (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_A0_REG)
            #define CS_DAB_1_IsCurrent_COUNTER_LSB_PTR    ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_A0_REG)
            #define CS_DAB_1_IsCurrent_CAPTURE_LSB        (*(reg16 *) CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_F1_REG)
            #define CS_DAB_1_IsCurrent_CAPTURE_LSB_PTR    ((reg16 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__16BIT_F1_REG)
        #endif /* (CY_PSOC3) */

       #define CS_DAB_1_IsCurrent_AUX_CONTROLDP1          (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u1__DP_AUX_CTL_REG)
       #define CS_DAB_1_IsCurrent_AUX_CONTROLDP1_PTR      ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u1__DP_AUX_CTL_REG)

   #endif /* (CS_DAB_1_IsCurrent_Resolution == 8) */

   #define CS_DAB_1_IsCurrent_COUNTERCAP_LSB_PTR_8BIT ( (reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__A1_REG)
   #define CS_DAB_1_IsCurrent_AUX_CONTROLDP0          (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__DP_AUX_CTL_REG)
   #define CS_DAB_1_IsCurrent_AUX_CONTROLDP0_PTR      ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sP16_pwmdp_u0__DP_AUX_CTL_REG)

#endif /* (CS_DAB_1_IsCurrent_UsingFixedFunction) */

#if(CS_DAB_1_IsCurrent_KillModeMinTime )
    #define CS_DAB_1_IsCurrent_KILLMODEMINTIME        (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    #define CS_DAB_1_IsCurrent_KILLMODEMINTIME_PTR    ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sKM_killmodecounterdp_u0__D0_REG)
    /* Fixed Function Block has no Kill Mode parameters because it is Asynchronous only */
#endif /* (CS_DAB_1_IsCurrent_KillModeMinTime ) */

#if(CS_DAB_1_IsCurrent_DeadBandMode == CS_DAB_1_IsCurrent__B_PWM__DBM_256_CLOCKS)
    #define CS_DAB_1_IsCurrent_DEADBAND_COUNT         (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
    #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_PTR     ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sDB255_deadbandcounterdp_u0__D0_REG)
    #define CS_DAB_1_IsCurrent_DEADBAND_LSB_PTR       ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_sDB255_deadbandcounterdp_u0__A0_REG)
    #define CS_DAB_1_IsCurrent_DEADBAND_LSB           (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_sDB255_deadbandcounterdp_u0__A0_REG)
#elif(CS_DAB_1_IsCurrent_DeadBandMode == CS_DAB_1_IsCurrent__B_PWM__DBM_2_4_CLOCKS)
    
    /* In Fixed Function Block these bits are in the control blocks control register */
    #if (CS_DAB_1_IsCurrent_UsingFixedFunction)
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT         (*(reg8 *)  CS_DAB_1_IsCurrent_PWMHW__CFG0)
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_PTR     ((reg8 *)   CS_DAB_1_IsCurrent_PWMHW__CFG0)
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_MASK    (uint8)((uint8)0x03u << CS_DAB_1_IsCurrent_DEADBAND_COUNT_SHIFT)

        /* As defined by the Register Map as DEADBAND_PERIOD[1:0] in CFG0 */
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_SHIFT   (0x06u)
    #else
        /* Lower two bits of the added control register define the count 1-3 */
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT         (*(reg8 *)  CS_DAB_1_IsCurrent_PWMUDB_genblk7_dbctrlreg__CONTROL_REG)
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_PTR     ((reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_genblk7_dbctrlreg__CONTROL_REG)
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_MASK    (uint8)((uint8)0x03u << CS_DAB_1_IsCurrent_DEADBAND_COUNT_SHIFT)

        /* As defined by the verilog implementation of the Control Register */
        #define CS_DAB_1_IsCurrent_DEADBAND_COUNT_SHIFT   (0x00u)
    #endif /* (CS_DAB_1_IsCurrent_UsingFixedFunction) */
#endif /* (CS_DAB_1_IsCurrent_DeadBandMode == CS_DAB_1_IsCurrent__B_PWM__DBM_256_CLOCKS) */



#if (CS_DAB_1_IsCurrent_UsingFixedFunction)
    #define CS_DAB_1_IsCurrent_STATUS                 (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__SR0)
    #define CS_DAB_1_IsCurrent_STATUS_PTR             ((reg8 *) CS_DAB_1_IsCurrent_PWMHW__SR0)
    #define CS_DAB_1_IsCurrent_STATUS_MASK            (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__SR0)
    #define CS_DAB_1_IsCurrent_STATUS_MASK_PTR        ((reg8 *) CS_DAB_1_IsCurrent_PWMHW__SR0)
    #define CS_DAB_1_IsCurrent_CONTROL                (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__CFG0)
    #define CS_DAB_1_IsCurrent_CONTROL_PTR            ((reg8 *) CS_DAB_1_IsCurrent_PWMHW__CFG0)
    #define CS_DAB_1_IsCurrent_CONTROL2               (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__CFG1)
    #define CS_DAB_1_IsCurrent_CONTROL3               (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__CFG2)
    #define CS_DAB_1_IsCurrent_GLOBAL_ENABLE          (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__PM_ACT_CFG)
    #define CS_DAB_1_IsCurrent_GLOBAL_ENABLE_PTR      ( (reg8 *) CS_DAB_1_IsCurrent_PWMHW__PM_ACT_CFG)
    #define CS_DAB_1_IsCurrent_GLOBAL_STBY_ENABLE     (*(reg8 *) CS_DAB_1_IsCurrent_PWMHW__PM_STBY_CFG)
    #define CS_DAB_1_IsCurrent_GLOBAL_STBY_ENABLE_PTR ( (reg8 *) CS_DAB_1_IsCurrent_PWMHW__PM_STBY_CFG)


    /***********************************
    *          Constants
    ***********************************/

    /* Fixed Function Block Chosen */
    #define CS_DAB_1_IsCurrent_BLOCK_EN_MASK          (CS_DAB_1_IsCurrent_PWMHW__PM_ACT_MSK)
    #define CS_DAB_1_IsCurrent_BLOCK_STBY_EN_MASK     (CS_DAB_1_IsCurrent_PWMHW__PM_STBY_MSK)
    
    /* Control Register definitions */
    #define CS_DAB_1_IsCurrent_CTRL_ENABLE_SHIFT      (0x00u)

    /* As defined by Register map as MODE_CFG bits in CFG2*/
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE1_SHIFT    (0x04u)

    /* As defined by Register map */
    #define CS_DAB_1_IsCurrent_CTRL_DEAD_TIME_SHIFT   (0x06u)  

    /* Fixed Function Block Only CFG register bit definitions */
    /*  Set to compare mode */
    #define CS_DAB_1_IsCurrent_CFG0_MODE              (0x02u)   

    /* Enable the block to run */
    #define CS_DAB_1_IsCurrent_CFG0_ENABLE            (0x01u)   
    
    /* As defined by Register map as DB bit in CFG0 */
    #define CS_DAB_1_IsCurrent_CFG0_DB                (0x20u)   

    /* Control Register Bit Masks */
    #define CS_DAB_1_IsCurrent_CTRL_ENABLE            (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_CTRL_ENABLE_SHIFT)
    #define CS_DAB_1_IsCurrent_CTRL_RESET             (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_CTRL_RESET_SHIFT)
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE2_MASK     (uint8)((uint8)0x07u << CS_DAB_1_IsCurrent_CTRL_CMPMODE2_SHIFT)
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE1_MASK     (uint8)((uint8)0x07u << CS_DAB_1_IsCurrent_CTRL_CMPMODE1_SHIFT)

    /* Control2 Register Bit Masks */
    /* As defined in Register Map, Part of the TMRX_CFG1 register */
    #define CS_DAB_1_IsCurrent_CTRL2_IRQ_SEL_SHIFT    (0x00u)
    #define CS_DAB_1_IsCurrent_CTRL2_IRQ_SEL          (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_CTRL2_IRQ_SEL_SHIFT)

    /* Status Register Bit Locations */
    /* As defined by Register map as TC in SR0 */
    #define CS_DAB_1_IsCurrent_STATUS_TC_SHIFT        (0x07u)   
    
    /* As defined by the Register map as CAP_CMP in SR0 */
    #define CS_DAB_1_IsCurrent_STATUS_CMP1_SHIFT      (0x06u)   

    /* Status Register Interrupt Enable Bit Locations */
    #define CS_DAB_1_IsCurrent_STATUS_KILL_INT_EN_MASK_SHIFT          (0x00u)
    #define CS_DAB_1_IsCurrent_STATUS_TC_INT_EN_MASK_SHIFT            (CS_DAB_1_IsCurrent_STATUS_TC_SHIFT - 4u)
    #define CS_DAB_1_IsCurrent_STATUS_CMP2_INT_EN_MASK_SHIFT          (0x00u)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1_INT_EN_MASK_SHIFT          (CS_DAB_1_IsCurrent_STATUS_CMP1_SHIFT - 4u)

    /* Status Register Bit Masks */
    #define CS_DAB_1_IsCurrent_STATUS_TC              (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_TC_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1            (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_CMP1_SHIFT)

    /* Status Register Interrupt Bit Masks */
    #define CS_DAB_1_IsCurrent_STATUS_TC_INT_EN_MASK              (uint8)((uint8)CS_DAB_1_IsCurrent_STATUS_TC >> 4u)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1_INT_EN_MASK            (uint8)((uint8)CS_DAB_1_IsCurrent_STATUS_CMP1 >> 4u)

    /*RT1 Synch Constants */
    #define CS_DAB_1_IsCurrent_RT1_SHIFT             (0x04u)

    /* Sync TC and CMP bit masks */
    #define CS_DAB_1_IsCurrent_RT1_MASK              (uint8)((uint8)0x03u << CS_DAB_1_IsCurrent_RT1_SHIFT)
    #define CS_DAB_1_IsCurrent_SYNC                  (uint8)((uint8)0x03u << CS_DAB_1_IsCurrent_RT1_SHIFT)
    #define CS_DAB_1_IsCurrent_SYNCDSI_SHIFT         (0x00u)

    /* Sync all DSI inputs */
    #define CS_DAB_1_IsCurrent_SYNCDSI_MASK          (uint8)((uint8)0x0Fu << CS_DAB_1_IsCurrent_SYNCDSI_SHIFT)

    /* Sync all DSI inputs */
    #define CS_DAB_1_IsCurrent_SYNCDSI_EN            (uint8)((uint8)0x0Fu << CS_DAB_1_IsCurrent_SYNCDSI_SHIFT)


#else
    #define CS_DAB_1_IsCurrent_STATUS                (*(reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__STATUS_REG )
    #define CS_DAB_1_IsCurrent_STATUS_PTR            ((reg8 *)    CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__STATUS_REG )
    #define CS_DAB_1_IsCurrent_STATUS_MASK           (*(reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__MASK_REG)
    #define CS_DAB_1_IsCurrent_STATUS_MASK_PTR       ((reg8 *)    CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__MASK_REG)
    #define CS_DAB_1_IsCurrent_STATUS_AUX_CTRL       (*(reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_genblk8_stsreg__STATUS_AUX_CTL_REG)
    #define CS_DAB_1_IsCurrent_CONTROL               (*(reg8 *)   CS_DAB_1_IsCurrent_PWMUDB_genblk1_ctrlreg__CONTROL_REG)
    #define CS_DAB_1_IsCurrent_CONTROL_PTR           ((reg8 *)    CS_DAB_1_IsCurrent_PWMUDB_genblk1_ctrlreg__CONTROL_REG)


    /***********************************
    *          Constants
    ***********************************/

    /* Control Register bit definitions */
    #define CS_DAB_1_IsCurrent_CTRL_ENABLE_SHIFT      (0x07u)
    #define CS_DAB_1_IsCurrent_CTRL_RESET_SHIFT       (0x06u)
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE2_SHIFT    (0x03u)
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE1_SHIFT    (0x00u)
    #define CS_DAB_1_IsCurrent_CTRL_DEAD_TIME_SHIFT   (0x00u)   /* No Shift Needed for UDB block */
    
    /* Control Register Bit Masks */
    #define CS_DAB_1_IsCurrent_CTRL_ENABLE            (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_CTRL_ENABLE_SHIFT)
    #define CS_DAB_1_IsCurrent_CTRL_RESET             (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_CTRL_RESET_SHIFT)
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE2_MASK     (uint8)((uint8)0x07u << CS_DAB_1_IsCurrent_CTRL_CMPMODE2_SHIFT)
    #define CS_DAB_1_IsCurrent_CTRL_CMPMODE1_MASK     (uint8)((uint8)0x07u << CS_DAB_1_IsCurrent_CTRL_CMPMODE1_SHIFT)

    /* Status Register Bit Locations */
    #define CS_DAB_1_IsCurrent_STATUS_KILL_SHIFT          (0x05u)
    #define CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY_SHIFT    (0x04u)
    #define CS_DAB_1_IsCurrent_STATUS_FIFOFULL_SHIFT      (0x03u)
    #define CS_DAB_1_IsCurrent_STATUS_TC_SHIFT            (0x02u)
    #define CS_DAB_1_IsCurrent_STATUS_CMP2_SHIFT          (0x01u)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1_SHIFT          (0x00u)

    /* Status Register Interrupt Enable Bit Locations - UDB Status Interrupt Mask match Status Bit Locations*/
    #define CS_DAB_1_IsCurrent_STATUS_KILL_INT_EN_MASK_SHIFT          (CS_DAB_1_IsCurrent_STATUS_KILL_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY_INT_EN_MASK_SHIFT    (CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_FIFOFULL_INT_EN_MASK_SHIFT      (CS_DAB_1_IsCurrent_STATUS_FIFOFULL_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_TC_INT_EN_MASK_SHIFT            (CS_DAB_1_IsCurrent_STATUS_TC_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_CMP2_INT_EN_MASK_SHIFT          (CS_DAB_1_IsCurrent_STATUS_CMP2_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1_INT_EN_MASK_SHIFT          (CS_DAB_1_IsCurrent_STATUS_CMP1_SHIFT)

    /* Status Register Bit Masks */
    #define CS_DAB_1_IsCurrent_STATUS_KILL            (uint8)((uint8)0x00u << CS_DAB_1_IsCurrent_STATUS_KILL_SHIFT )
    #define CS_DAB_1_IsCurrent_STATUS_FIFOFULL        (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_FIFOFULL_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY      (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_TC              (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_TC_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_CMP2            (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_CMP2_SHIFT)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1            (uint8)((uint8)0x01u << CS_DAB_1_IsCurrent_STATUS_CMP1_SHIFT)

    /* Status Register Interrupt Bit Masks  - UDB Status Interrupt Mask match Status Bit Locations */
    #define CS_DAB_1_IsCurrent_STATUS_KILL_INT_EN_MASK            (CS_DAB_1_IsCurrent_STATUS_KILL)
    #define CS_DAB_1_IsCurrent_STATUS_FIFOFULL_INT_EN_MASK        (CS_DAB_1_IsCurrent_STATUS_FIFOFULL)
    #define CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY_INT_EN_MASK      (CS_DAB_1_IsCurrent_STATUS_FIFONEMPTY)
    #define CS_DAB_1_IsCurrent_STATUS_TC_INT_EN_MASK              (CS_DAB_1_IsCurrent_STATUS_TC)
    #define CS_DAB_1_IsCurrent_STATUS_CMP2_INT_EN_MASK            (CS_DAB_1_IsCurrent_STATUS_CMP2)
    #define CS_DAB_1_IsCurrent_STATUS_CMP1_INT_EN_MASK            (CS_DAB_1_IsCurrent_STATUS_CMP1)

    /* Datapath Auxillary Control Register bit definitions */
    #define CS_DAB_1_IsCurrent_AUX_CTRL_FIFO0_CLR         (0x01u)
    #define CS_DAB_1_IsCurrent_AUX_CTRL_FIFO1_CLR         (0x02u)
    #define CS_DAB_1_IsCurrent_AUX_CTRL_FIFO0_LVL         (0x04u)
    #define CS_DAB_1_IsCurrent_AUX_CTRL_FIFO1_LVL         (0x08u)
    #define CS_DAB_1_IsCurrent_STATUS_ACTL_INT_EN_MASK    (0x10u) /* As defined for the ACTL Register */
#endif /* CS_DAB_1_IsCurrent_UsingFixedFunction */

#endif  /* CY_PWM_CS_DAB_1_IsCurrent_H */


/* [] END OF FILE */
