/*******************************************************************************
* File Name: Bridge_H_S_out_CH1.h  
* Version 2.10
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Bridge_H_S_out_CH1_H) /* Pins Bridge_H_S_out_CH1_H */
#define CY_PINS_Bridge_H_S_out_CH1_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Bridge_H_S_out_CH1_aliases.h"

/* Check to see if required defines such as CY_PSOC5A are available */
/* They are defined starting with cy_boot v3.0 */
#if !defined (CY_PSOC5A)
    #error Component cy_pins_v2_10 requires cy_boot v3.0 or later
#endif /* (CY_PSOC5A) */

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 Bridge_H_S_out_CH1__PORT == 15 && ((Bridge_H_S_out_CH1__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

void    Bridge_H_S_out_CH1_Write(uint8 value) ;
void    Bridge_H_S_out_CH1_SetDriveMode(uint8 mode) ;
uint8   Bridge_H_S_out_CH1_ReadDataReg(void) ;
uint8   Bridge_H_S_out_CH1_Read(void) ;
uint8   Bridge_H_S_out_CH1_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Bridge_H_S_out_CH1_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Bridge_H_S_out_CH1_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Bridge_H_S_out_CH1_DM_RES_UP          PIN_DM_RES_UP
#define Bridge_H_S_out_CH1_DM_RES_DWN         PIN_DM_RES_DWN
#define Bridge_H_S_out_CH1_DM_OD_LO           PIN_DM_OD_LO
#define Bridge_H_S_out_CH1_DM_OD_HI           PIN_DM_OD_HI
#define Bridge_H_S_out_CH1_DM_STRONG          PIN_DM_STRONG
#define Bridge_H_S_out_CH1_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Bridge_H_S_out_CH1_MASK               Bridge_H_S_out_CH1__MASK
#define Bridge_H_S_out_CH1_SHIFT              Bridge_H_S_out_CH1__SHIFT
#define Bridge_H_S_out_CH1_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Bridge_H_S_out_CH1_PS                     (* (reg8 *) Bridge_H_S_out_CH1__PS)
/* Data Register */
#define Bridge_H_S_out_CH1_DR                     (* (reg8 *) Bridge_H_S_out_CH1__DR)
/* Port Number */
#define Bridge_H_S_out_CH1_PRT_NUM                (* (reg8 *) Bridge_H_S_out_CH1__PRT) 
/* Connect to Analog Globals */                                                  
#define Bridge_H_S_out_CH1_AG                     (* (reg8 *) Bridge_H_S_out_CH1__AG)                       
/* Analog MUX bux enable */
#define Bridge_H_S_out_CH1_AMUX                   (* (reg8 *) Bridge_H_S_out_CH1__AMUX) 
/* Bidirectional Enable */                                                        
#define Bridge_H_S_out_CH1_BIE                    (* (reg8 *) Bridge_H_S_out_CH1__BIE)
/* Bit-mask for Aliased Register Access */
#define Bridge_H_S_out_CH1_BIT_MASK               (* (reg8 *) Bridge_H_S_out_CH1__BIT_MASK)
/* Bypass Enable */
#define Bridge_H_S_out_CH1_BYP                    (* (reg8 *) Bridge_H_S_out_CH1__BYP)
/* Port wide control signals */                                                   
#define Bridge_H_S_out_CH1_CTL                    (* (reg8 *) Bridge_H_S_out_CH1__CTL)
/* Drive Modes */
#define Bridge_H_S_out_CH1_DM0                    (* (reg8 *) Bridge_H_S_out_CH1__DM0) 
#define Bridge_H_S_out_CH1_DM1                    (* (reg8 *) Bridge_H_S_out_CH1__DM1)
#define Bridge_H_S_out_CH1_DM2                    (* (reg8 *) Bridge_H_S_out_CH1__DM2) 
/* Input Buffer Disable Override */
#define Bridge_H_S_out_CH1_INP_DIS                (* (reg8 *) Bridge_H_S_out_CH1__INP_DIS)
/* LCD Common or Segment Drive */
#define Bridge_H_S_out_CH1_LCD_COM_SEG            (* (reg8 *) Bridge_H_S_out_CH1__LCD_COM_SEG)
/* Enable Segment LCD */
#define Bridge_H_S_out_CH1_LCD_EN                 (* (reg8 *) Bridge_H_S_out_CH1__LCD_EN)
/* Slew Rate Control */
#define Bridge_H_S_out_CH1_SLW                    (* (reg8 *) Bridge_H_S_out_CH1__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Bridge_H_S_out_CH1_PRTDSI__CAPS_SEL       (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Bridge_H_S_out_CH1_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Bridge_H_S_out_CH1_PRTDSI__OE_SEL0        (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__OE_SEL0) 
#define Bridge_H_S_out_CH1_PRTDSI__OE_SEL1        (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Bridge_H_S_out_CH1_PRTDSI__OUT_SEL0       (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__OUT_SEL0) 
#define Bridge_H_S_out_CH1_PRTDSI__OUT_SEL1       (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Bridge_H_S_out_CH1_PRTDSI__SYNC_OUT       (* (reg8 *) Bridge_H_S_out_CH1__PRTDSI__SYNC_OUT) 


#if defined(Bridge_H_S_out_CH1__INTSTAT)  /* Interrupt Registers */

    #define Bridge_H_S_out_CH1_INTSTAT                (* (reg8 *) Bridge_H_S_out_CH1__INTSTAT)
    #define Bridge_H_S_out_CH1_SNAP                   (* (reg8 *) Bridge_H_S_out_CH1__SNAP)

#endif /* Interrupt Registers */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_Bridge_H_S_out_CH1_H */


/* [] END OF FILE */
