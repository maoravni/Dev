/*******************************************************************************
* File Name: CS_DAB_1_Z_isr.h
* Version 1.70
*
*  Description:
*   Provides the function definitions for the Interrupt Controller.
*
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/
#if !defined(CY_ISR_CS_DAB_1_Z_isr_H)
#define CY_ISR_CS_DAB_1_Z_isr_H


#include <cytypes.h>
#include <cyfitter.h>

/* Interrupt Controller API. */
void CS_DAB_1_Z_isr_Start(void);
void CS_DAB_1_Z_isr_StartEx(cyisraddress address);
void CS_DAB_1_Z_isr_Stop(void);

CY_ISR_PROTO(CS_DAB_1_Z_isr_Interrupt);

void CS_DAB_1_Z_isr_SetVector(cyisraddress address);
cyisraddress CS_DAB_1_Z_isr_GetVector(void);

void CS_DAB_1_Z_isr_SetPriority(uint8 priority);
uint8 CS_DAB_1_Z_isr_GetPriority(void);

void CS_DAB_1_Z_isr_Enable(void);
uint8 CS_DAB_1_Z_isr_GetState(void);
void CS_DAB_1_Z_isr_Disable(void);

void CS_DAB_1_Z_isr_SetPending(void);
void CS_DAB_1_Z_isr_ClearPending(void);


/* Interrupt Controller Constants */

/* Address of the INTC.VECT[x] register that contains the Address of the CS_DAB_1_Z_isr ISR. */
#define CS_DAB_1_Z_isr_INTC_VECTOR            ((reg32 *) CS_DAB_1_Z_isr__INTC_VECT)

/* Address of the CS_DAB_1_Z_isr ISR priority. */
#define CS_DAB_1_Z_isr_INTC_PRIOR             ((reg8 *) CS_DAB_1_Z_isr__INTC_PRIOR_REG)

/* Priority of the CS_DAB_1_Z_isr interrupt. */
#define CS_DAB_1_Z_isr_INTC_PRIOR_NUMBER      CS_DAB_1_Z_isr__INTC_PRIOR_NUM

/* Address of the INTC.SET_EN[x] byte to bit enable CS_DAB_1_Z_isr interrupt. */
#define CS_DAB_1_Z_isr_INTC_SET_EN            ((reg32 *) CS_DAB_1_Z_isr__INTC_SET_EN_REG)

/* Address of the INTC.CLR_EN[x] register to bit clear the CS_DAB_1_Z_isr interrupt. */
#define CS_DAB_1_Z_isr_INTC_CLR_EN            ((reg32 *) CS_DAB_1_Z_isr__INTC_CLR_EN_REG)

/* Address of the INTC.SET_PD[x] register to set the CS_DAB_1_Z_isr interrupt state to pending. */
#define CS_DAB_1_Z_isr_INTC_SET_PD            ((reg32 *) CS_DAB_1_Z_isr__INTC_SET_PD_REG)

/* Address of the INTC.CLR_PD[x] register to clear the CS_DAB_1_Z_isr interrupt. */
#define CS_DAB_1_Z_isr_INTC_CLR_PD            ((reg32 *) CS_DAB_1_Z_isr__INTC_CLR_PD_REG)


#endif /* CY_ISR_CS_DAB_1_Z_isr_H */


/* [] END OF FILE */
