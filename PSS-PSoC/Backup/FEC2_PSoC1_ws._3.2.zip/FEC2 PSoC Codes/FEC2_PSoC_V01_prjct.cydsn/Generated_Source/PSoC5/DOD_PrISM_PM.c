/*******************************************************************************
* File Name: DOD_PrISM_PM.c
* Version 2.20
*
* Description:
*  This file provides Sleep/WakeUp APIs functionality of the PrISM component
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#include "DOD_PrISM.h"


/***************************************
* Local data allocation
***************************************/
static DOD_PrISM_BACKUP_STRUCT  DOD_PrISM_backup = 
{
    /* enableState */
    0u,
    /* cr */
    #if(!DOD_PrISM_PULSE_TYPE_HARDCODED)
       (((DOD_PrISM_GREATERTHAN_OR_EQUAL == DOD_PrISM_COMPARE0) ? \
                                                DOD_PrISM_CTRL_COMPARE_TYPE0_GREATER_THAN_OR_EQUAL : 0u) |
        ((DOD_PrISM_GREATERTHAN_OR_EQUAL == DOD_PrISM_COMPARE1) ? \
                                                DOD_PrISM_CTRL_COMPARE_TYPE1_GREATER_THAN_OR_EQUAL : 0u)),
    #endif /* End DOD_PrISM_PULSE_TYPE_HARDCODED */
    /* seed */    
    DOD_PrISM_SEED,
    /* seed_copy */    
    DOD_PrISM_SEED,
    /* polynom */
    DOD_PrISM_POLYNOM,
    #if(CY_UDB_V0)
        /* density0 */
        DOD_PrISM_DENSITY0,
        /* density1 */
        DOD_PrISM_DENSITY1,
    #endif /*End CY_UDB_V0*/
};


/*******************************************************************************
* Function Name: DOD_PrISM_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration.
*  
* Parameters:  
*  None.
*
* Return: 
*  None.
*
* Global Variables:
*  DOD_PrISM_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void DOD_PrISM_SaveConfig(void) 
{
    #if (CY_UDB_V0)
        #if(!DOD_PrISM_PULSE_TYPE_HARDCODED)
            DOD_PrISM_backup.cr = DOD_PrISM_CONTROL_REG;
        #endif /* End DOD_PrISM_PULSE_TYPE_HARDCODED */
        DOD_PrISM_backup.seed = DOD_PrISM_ReadSeed();
        DOD_PrISM_backup.seed_copy = CY_GET_REG16(DOD_PrISM_SEED_COPY_PTR);
        DOD_PrISM_backup.polynom = DOD_PrISM_ReadPolynomial();
        DOD_PrISM_backup.density0 = DOD_PrISM_ReadPulse0();
        DOD_PrISM_backup.density1 = DOD_PrISM_ReadPulse1();
    #else /* CY_UDB_V1 */
        #if(!DOD_PrISM_PULSE_TYPE_HARDCODED)
            DOD_PrISM_backup.cr = DOD_PrISM_CONTROL_REG;
        #endif /* End DOD_PrISM_PULSE_TYPE_HARDCODED */
        DOD_PrISM_backup.seed = DOD_PrISM_ReadSeed();
        DOD_PrISM_backup.seed_copy = CY_GET_REG16(DOD_PrISM_SEED_COPY_PTR);
        DOD_PrISM_backup.polynom = DOD_PrISM_ReadPolynomial();
    #endif  /* CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: DOD_PrISM_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration.
*
* Parameters:  
*  None.
*
* Return: 
*  None.
*
* Global Variables:
*  DOD_PrISM_backup - used when non-retention registers are restored.
*
*******************************************************************************/
void DOD_PrISM_RestoreConfig(void) 
{
    #if (CY_UDB_V0)
    
        uint8 enableInterrupts;
        
        #if(!DOD_PrISM_PULSE_TYPE_HARDCODED)
            DOD_PrISM_CONTROL_REG = DOD_PrISM_backup.cr;
        #endif /* End DOD_PrISM_PULSE_TYPE_HARDCODED */

        CY_SET_REG16(DOD_PrISM_SEED_COPY_PTR, DOD_PrISM_backup.seed_copy);
        CY_SET_REG16(DOD_PrISM_SEED_PTR, DOD_PrISM_backup.seed);
        DOD_PrISM_WritePolynomial(DOD_PrISM_backup.polynom);
        DOD_PrISM_WritePulse0(DOD_PrISM_backup.density0);
        DOD_PrISM_WritePulse1(DOD_PrISM_backup.density1);
        
        enableInterrupts = CyEnterCriticalSection();
        /* Set FIFO0_CLR bit to use FIFO0 as a simple one-byte buffer*/
        CY_SET_REG16(DOD_PrISM_AUX_CONTROL_PTR, 
                        CY_GET_REG16(DOD_PrISM_AUX_CONTROL_PTR) | DOD_PrISM_FIFO0_CLR);
        CyExitCriticalSection(enableInterrupts);

    #else   /* CY_UDB_V1 */

        #if(!DOD_PrISM_PULSE_TYPE_HARDCODED)
            DOD_PrISM_CONTROL_REG = DOD_PrISM_backup.cr;
        #endif /* End DOD_PrISM_PULSE_TYPE_HARDCODED */

        CY_SET_REG16(DOD_PrISM_SEED_COPY_PTR, DOD_PrISM_backup.seed_copy);
        CY_SET_REG16(DOD_PrISM_SEED_PTR, DOD_PrISM_backup.seed);
        DOD_PrISM_WritePolynomial(DOD_PrISM_backup.polynom);
    
    #endif  /* End CY_UDB_V0 */
}


/*******************************************************************************
* Function Name: DOD_PrISM_Sleep
********************************************************************************
*
* Summary:
*  Stops and saves the user configuration
*  
* Parameters:  
*  None.
*
* Return: 
*  None.
*
* Global Variables:
*  DOD_PrISM_backup - modified when non-retention registers are saved.
*
* Reentrant:
*  No.
*
*******************************************************************************/
void DOD_PrISM_Sleep(void) 
{
    #if(!DOD_PrISM_PULSE_TYPE_HARDCODED)
        if((DOD_PrISM_CONTROL_REG & DOD_PrISM_CTRL_ENABLE) != 0u) 
        {
            DOD_PrISM_backup.enableState = 1u;
        }
        else
        {
            DOD_PrISM_backup.enableState = 0u;
        }
    #endif /* End DOD_PrISM_PULSE_TYPE_HARDCODED */
    DOD_PrISM_Stop();
    DOD_PrISM_SaveConfig();
}


/*******************************************************************************
* Function Name: DOD_PrISM_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration
*  
* Parameters:  
*  None.
*
* Return: 
*  None.
*
* Global Variables:
*  DOD_PrISM_backup - used when non-retention registers are restored.
*
*******************************************************************************/
void DOD_PrISM_Wakeup(void) 
{
    DOD_PrISM_RestoreConfig();
    if(DOD_PrISM_backup.enableState != 0u)
    {
        DOD_PrISM_Enable();
    } 
}


/* [] END OF FILE */
