/*******************************************************************************
* File Name: DOD_PWM_4_PM.c
* Version 3.10
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "DOD_PWM_4.h"

static DOD_PWM_4_backupStruct DOD_PWM_4_backup;


/*******************************************************************************
* Function Name: DOD_PWM_4_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_4_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void DOD_PWM_4_SaveConfig(void) 
{

    #if(!DOD_PWM_4_UsingFixedFunction)
        #if(!DOD_PWM_4_PWMModeIsCenterAligned)
            DOD_PWM_4_backup.PWMPeriod = DOD_PWM_4_ReadPeriod();
        #endif /* (!DOD_PWM_4_PWMModeIsCenterAligned) */
        DOD_PWM_4_backup.PWMUdb = DOD_PWM_4_ReadCounter();
        #if (DOD_PWM_4_UseStatus)
            DOD_PWM_4_backup.InterruptMaskValue = DOD_PWM_4_STATUS_MASK;
        #endif /* (DOD_PWM_4_UseStatus) */

        #if(DOD_PWM_4_DeadBandMode == DOD_PWM_4__B_PWM__DBM_256_CLOCKS || \
            DOD_PWM_4_DeadBandMode == DOD_PWM_4__B_PWM__DBM_2_4_CLOCKS)
            DOD_PWM_4_backup.PWMdeadBandValue = DOD_PWM_4_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(DOD_PWM_4_KillModeMinTime)
             DOD_PWM_4_backup.PWMKillCounterPeriod = DOD_PWM_4_ReadKillTime();
        #endif /* (DOD_PWM_4_KillModeMinTime) */

        #if(DOD_PWM_4_UseControl)
            DOD_PWM_4_backup.PWMControlRegister = DOD_PWM_4_ReadControlRegister();
        #endif /* (DOD_PWM_4_UseControl) */
    #endif  /* (!DOD_PWM_4_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: DOD_PWM_4_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_4_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void DOD_PWM_4_RestoreConfig(void) 
{
        #if(!DOD_PWM_4_UsingFixedFunction)
            #if(!DOD_PWM_4_PWMModeIsCenterAligned)
                DOD_PWM_4_WritePeriod(DOD_PWM_4_backup.PWMPeriod);
            #endif /* (!DOD_PWM_4_PWMModeIsCenterAligned) */

            DOD_PWM_4_WriteCounter(DOD_PWM_4_backup.PWMUdb);

            #if (DOD_PWM_4_UseStatus)
                DOD_PWM_4_STATUS_MASK = DOD_PWM_4_backup.InterruptMaskValue;
            #endif /* (DOD_PWM_4_UseStatus) */

            #if(DOD_PWM_4_DeadBandMode == DOD_PWM_4__B_PWM__DBM_256_CLOCKS || \
                DOD_PWM_4_DeadBandMode == DOD_PWM_4__B_PWM__DBM_2_4_CLOCKS)
                DOD_PWM_4_WriteDeadTime(DOD_PWM_4_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(DOD_PWM_4_KillModeMinTime)
                DOD_PWM_4_WriteKillTime(DOD_PWM_4_backup.PWMKillCounterPeriod);
            #endif /* (DOD_PWM_4_KillModeMinTime) */

            #if(DOD_PWM_4_UseControl)
                DOD_PWM_4_WriteControlRegister(DOD_PWM_4_backup.PWMControlRegister);
            #endif /* (DOD_PWM_4_UseControl) */
        #endif  /* (!DOD_PWM_4_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: DOD_PWM_4_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_4_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void DOD_PWM_4_Sleep(void) 
{
    #if(DOD_PWM_4_UseControl)
        if(DOD_PWM_4_CTRL_ENABLE == (DOD_PWM_4_CONTROL & DOD_PWM_4_CTRL_ENABLE))
        {
            /*Component is enabled */
            DOD_PWM_4_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            DOD_PWM_4_backup.PWMEnableState = 0u;
        }
    #endif /* (DOD_PWM_4_UseControl) */

    /* Stop component */
    DOD_PWM_4_Stop();

    /* Save registers configuration */
    DOD_PWM_4_SaveConfig();
}


/*******************************************************************************
* Function Name: DOD_PWM_4_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  DOD_PWM_4_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void DOD_PWM_4_Wakeup(void) 
{
     /* Restore registers values */
    DOD_PWM_4_RestoreConfig();

    if(DOD_PWM_4_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        DOD_PWM_4_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
