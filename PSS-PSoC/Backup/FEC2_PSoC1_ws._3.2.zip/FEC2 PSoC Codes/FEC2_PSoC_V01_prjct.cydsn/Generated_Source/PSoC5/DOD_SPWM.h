/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <cytypes.h>

#if !defined (DOD_SPWM_H )
#define DOD_SPWM_H 

void DOD_SPWM_Init(void);
void DOD_SPWM_SetMode(uint8 Mode);
void DOD_SPWM_Write_DC(uint8 DC);
uint8 DOD_SPWM_Read_DC(void);
#endif
/* [] END OF FILE */
