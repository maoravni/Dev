/*******************************************************************************
* File Name: LED_Flasher_PM.c
* Version 3.10
*
* Description:
*  This file provides the power management source code to API for the
*  PWM.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "LED_Flasher.h"

static LED_Flasher_backupStruct LED_Flasher_backup;


/*******************************************************************************
* Function Name: LED_Flasher_SaveConfig
********************************************************************************
*
* Summary:
*  Saves the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  LED_Flasher_backup:  Variables of this global structure are modified to
*  store the values of non retention configuration registers when Sleep() API is
*  called.
*
*******************************************************************************/
void LED_Flasher_SaveConfig(void) 
{

    #if(!LED_Flasher_UsingFixedFunction)
        #if(!LED_Flasher_PWMModeIsCenterAligned)
            LED_Flasher_backup.PWMPeriod = LED_Flasher_ReadPeriod();
        #endif /* (!LED_Flasher_PWMModeIsCenterAligned) */
        LED_Flasher_backup.PWMUdb = LED_Flasher_ReadCounter();
        #if (LED_Flasher_UseStatus)
            LED_Flasher_backup.InterruptMaskValue = LED_Flasher_STATUS_MASK;
        #endif /* (LED_Flasher_UseStatus) */

        #if(LED_Flasher_DeadBandMode == LED_Flasher__B_PWM__DBM_256_CLOCKS || \
            LED_Flasher_DeadBandMode == LED_Flasher__B_PWM__DBM_2_4_CLOCKS)
            LED_Flasher_backup.PWMdeadBandValue = LED_Flasher_ReadDeadTime();
        #endif /*  deadband count is either 2-4 clocks or 256 clocks */

        #if(LED_Flasher_KillModeMinTime)
             LED_Flasher_backup.PWMKillCounterPeriod = LED_Flasher_ReadKillTime();
        #endif /* (LED_Flasher_KillModeMinTime) */

        #if(LED_Flasher_UseControl)
            LED_Flasher_backup.PWMControlRegister = LED_Flasher_ReadControlRegister();
        #endif /* (LED_Flasher_UseControl) */
    #endif  /* (!LED_Flasher_UsingFixedFunction) */
}


/*******************************************************************************
* Function Name: LED_Flasher_RestoreConfig
********************************************************************************
*
* Summary:
*  Restores the current user configuration of the component.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  LED_Flasher_backup:  Variables of this global structure are used to
*  restore the values of non retention registers on wakeup from sleep mode.
*
*******************************************************************************/
void LED_Flasher_RestoreConfig(void) 
{
        #if(!LED_Flasher_UsingFixedFunction)
            #if(!LED_Flasher_PWMModeIsCenterAligned)
                LED_Flasher_WritePeriod(LED_Flasher_backup.PWMPeriod);
            #endif /* (!LED_Flasher_PWMModeIsCenterAligned) */

            LED_Flasher_WriteCounter(LED_Flasher_backup.PWMUdb);

            #if (LED_Flasher_UseStatus)
                LED_Flasher_STATUS_MASK = LED_Flasher_backup.InterruptMaskValue;
            #endif /* (LED_Flasher_UseStatus) */

            #if(LED_Flasher_DeadBandMode == LED_Flasher__B_PWM__DBM_256_CLOCKS || \
                LED_Flasher_DeadBandMode == LED_Flasher__B_PWM__DBM_2_4_CLOCKS)
                LED_Flasher_WriteDeadTime(LED_Flasher_backup.PWMdeadBandValue);
            #endif /* deadband count is either 2-4 clocks or 256 clocks */

            #if(LED_Flasher_KillModeMinTime)
                LED_Flasher_WriteKillTime(LED_Flasher_backup.PWMKillCounterPeriod);
            #endif /* (LED_Flasher_KillModeMinTime) */

            #if(LED_Flasher_UseControl)
                LED_Flasher_WriteControlRegister(LED_Flasher_backup.PWMControlRegister);
            #endif /* (LED_Flasher_UseControl) */
        #endif  /* (!LED_Flasher_UsingFixedFunction) */
    }


/*******************************************************************************
* Function Name: LED_Flasher_Sleep
********************************************************************************
*
* Summary:
*  Disables block's operation and saves the user configuration. Should be called
*  just prior to entering sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  LED_Flasher_backup.PWMEnableState:  Is modified depending on the enable
*  state of the block before entering sleep mode.
*
*******************************************************************************/
void LED_Flasher_Sleep(void) 
{
    #if(LED_Flasher_UseControl)
        if(LED_Flasher_CTRL_ENABLE == (LED_Flasher_CONTROL & LED_Flasher_CTRL_ENABLE))
        {
            /*Component is enabled */
            LED_Flasher_backup.PWMEnableState = 1u;
        }
        else
        {
            /* Component is disabled */
            LED_Flasher_backup.PWMEnableState = 0u;
        }
    #endif /* (LED_Flasher_UseControl) */

    /* Stop component */
    LED_Flasher_Stop();

    /* Save registers configuration */
    LED_Flasher_SaveConfig();
}


/*******************************************************************************
* Function Name: LED_Flasher_Wakeup
********************************************************************************
*
* Summary:
*  Restores and enables the user configuration. Should be called just after
*  awaking from sleep.
*
* Parameters:
*  None
*
* Return:
*  None
*
* Global variables:
*  LED_Flasher_backup.pwmEnable:  Is used to restore the enable state of
*  block on wakeup from sleep mode.
*
*******************************************************************************/
void LED_Flasher_Wakeup(void) 
{
     /* Restore registers values */
    LED_Flasher_RestoreConfig();

    if(LED_Flasher_backup.PWMEnableState != 0u)
    {
        /* Enable component's operation */
        LED_Flasher_Enable();
    } /* Do nothing if component's block was disabled before */

}


/* [] END OF FILE */
